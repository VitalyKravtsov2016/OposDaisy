package com.daisy.devicecommunicationSDK;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

class LineMenuAdapter extends ArrayAdapter<LineMenu> {

    LineMenuAdapter(Context context, ArrayList<LineMenu> lineMenu) {
        super(context, 0, lineMenu);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LineMenu lineMenu = getItem(position);

        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.block_layout_bluetooth_device, parent, false);
        }

        TextView lineTitle = convertView.findViewById(R.id.txtTitle);
        TextView lineText = convertView.findViewById(R.id.txtDescription);

        if (lineMenu != null) {
            lineTitle.setText(lineMenu.getTitle());
            lineText.setText(lineMenu.getAddress());
        }
        return convertView;
    }
}
