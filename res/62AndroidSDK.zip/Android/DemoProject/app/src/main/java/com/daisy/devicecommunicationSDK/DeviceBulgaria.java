package com.daisy.devicecommunicationSDK;

import java.io.IOException;

/**
 * Class for bulgarian fiscal devices. Extends FiscalDevice and overrides all the commands.
 */
public class DeviceBulgaria extends FiscalDevice {
    private SerialSocket socket;
    private DeviceResponse deviceResponse;

    DeviceBulgaria(SerialSocket socket) {
        super();

        this.socket = socket;
        deviceCommunication = new DeviceCommunication();
        deviceResponse = getDeviceResponse();
    }

    private byte[] GetCustomCommand(int code, String data) {
        try {
            return deviceCommunication.GetByteArray(new StringBuilder(data), code);
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public void GetPasswordBLE(){
        deviceResponse.setCurrentCommand(199);
        deviceResponse.setRequest(GetCustomCommand(deviceResponse.getCurrentCommand(), ""));
        try {
            socket.write(deviceResponse.getRequest());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void ConfirmPasswordBLE(String pass){
        deviceResponse.setCurrentCommand(200);
        deviceResponse.setRequest(GetCustomCommand(deviceResponse.getCurrentCommand(), pass));

        try {
            socket.write(deviceResponse.getRequest());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public DeviceResponse FDMovePaper() {
        deviceResponse.setCurrentCommand(44);
        deviceResponse.setRequest(GetCustomCommand(deviceResponse.getCurrentCommand(), "1"));

        try {
            socket.write(deviceResponse.getRequest());
        } catch (IOException e) {
            e.printStackTrace();
        }

        return deviceResponse;
    }

    @Override
    public DeviceResponse FDGetLastDocNumber() {
        deviceResponse.setCurrentCommand(113);
        deviceResponse.setRequest(GetCustomCommand(deviceResponse.getCurrentCommand(), ""));

        try {
            socket.write(deviceResponse.getRequest());
        } catch (IOException e) {
            e.printStackTrace();
        }

        return deviceResponse;
    }

    @Override
    public DeviceResponse FDGetStatus() {
        deviceResponse.setCurrentCommand(74);
        deviceResponse.setRequest(GetCustomCommand(deviceResponse.getCurrentCommand(), ""));

        try {
            socket.write(deviceResponse.getRequest());
        } catch (IOException e) {
            e.printStackTrace();
        }

        return deviceResponse;
    }

    @Override
    public DeviceResponse FDGetFinalRecord() {
        deviceResponse.setCurrentCommand(64);
        deviceResponse.setRequest(GetCustomCommand(deviceResponse.getCurrentCommand(), "N"));

        try {
            socket.write(deviceResponse.getRequest());
        } catch (IOException e) {
            e.printStackTrace();
        }

        return deviceResponse;
    }

    @Override
    public DeviceResponse FDGetDiagnosticInfo() {
        deviceResponse.setCurrentCommand(71);
        deviceResponse.setRequest(GetCustomCommand(deviceResponse.getCurrentCommand(), ""));

        try {
            socket.write(deviceResponse.getRequest());
        } catch (IOException e) {
            e.printStackTrace();
        }

        return deviceResponse;
    }

    @Override
    public DeviceResponse FDGetTaxRates() {
        deviceResponse.setCurrentCommand(97);
        deviceResponse.setRequest(GetCustomCommand(deviceResponse.getCurrentCommand(), ""));

        try {
            socket.write(deviceResponse.getRequest());
        } catch (IOException e) {
            e.printStackTrace();
        }

        return deviceResponse;
    }

    @Override
    public DeviceResponse FDProgramPLU(String taxGroup, String pluNumber, String price, String name, String barcode, String department, String stockQuantity) {
        deviceResponse.setCurrentCommand(107);

        StringBuilder str = new StringBuilder();
        str.append("P");
        str.append(taxGroup);
        str.append(pluNumber);
        str.append(",");
        str.append(price);
        str.append(",");
        str.append(name);
        str.append("\n");
        str.append(barcode);
        str.append(",");

        //Add zero to the string so 1 becomes 01.
        if (department.length() == 1) {
            str.append("0");
        }

        str.append(department.replace(",", "."));
        str.append(",1,");
        str.append(stockQuantity.replace(",", "."));

        deviceResponse.setRequest(GetCustomCommand(deviceResponse.getCurrentCommand(), str.toString()));

        try {
            socket.write(deviceResponse.getRequest());
        } catch (IOException e) {
            e.printStackTrace();
        }

        return deviceResponse;
    }

    @Override
    public DeviceResponse FDReadPLU(String pluNumber) {
        deviceResponse.setCurrentCommand(107);

        deviceResponse.setRequest(GetCustomCommand(deviceResponse.getCurrentCommand(), "R" + pluNumber));

        try {
            socket.write(deviceResponse.getRequest());
        } catch (IOException e) {
            e.printStackTrace();
        }

        return deviceResponse;
    }

    @Override
    public DeviceResponse FDReadFirstPLU() {
        deviceResponse.setCurrentCommand(107);
        deviceResponse.setRequest(GetCustomCommand(deviceResponse.getCurrentCommand(), "F0"));

        try {
            socket.write(deviceResponse.getRequest());
        } catch (IOException e) {
            e.printStackTrace();
        }

        return deviceResponse;
    }

    @Override
    public DeviceResponse FDReadNextPLU() {
        deviceResponse.setCurrentCommand(107);
        deviceResponse.setRequest(GetCustomCommand(deviceResponse.getCurrentCommand(), "N"));

        try {
            socket.write(deviceResponse.getRequest());
        } catch (IOException e) {
            e.printStackTrace();
        }

        return deviceResponse;
    }

    @Override
    public DeviceResponse FDDeletePLU(String pluNumber) {
        deviceResponse.setCurrentCommand(107);

        deviceResponse.setRequest(GetCustomCommand(deviceResponse.getCurrentCommand(), "D" + pluNumber));

        try {
            socket.write(deviceResponse.getRequest());
        } catch (IOException e) {
            e.printStackTrace();
        }

        return deviceResponse;
    }

    @Override
    public DeviceResponse FDProgramDPT(String deptNumber, String name, String taxGroup, String maxDigits) {
        StringBuilder str = new StringBuilder("P");
        str.append(deptNumber);
        str.append(",");
        str.append(name);
        str.append("\n");
        str.append(taxGroup);
        str.append(",0,");

        if (maxDigits.isEmpty()) {
            str.append("0");
        } else {
            str.append(maxDigits);
        }

        deviceResponse.setCurrentCommand(131);
        deviceResponse.setRequest(GetCustomCommand(deviceResponse.getCurrentCommand(), str.toString()));

        try {
            socket.write(deviceResponse.getRequest());
        } catch (IOException e) {
            e.printStackTrace();
        }

        return deviceResponse;
    }

    @Override
    public DeviceResponse FDReadDPT(String deptNumber) {
        deviceResponse.setCurrentCommand(131);
        deviceResponse.setRequest(GetCustomCommand(deviceResponse.getCurrentCommand(), "R" + deptNumber));

        try {
            socket.write(deviceResponse.getRequest());
        } catch (IOException e) {
            e.printStackTrace();
        }

        return deviceResponse;
    }

    @Override
    public DeviceResponse FDGetDateTime() {
        deviceResponse.setCurrentCommand(62);
        deviceResponse.setRequest(GetCustomCommand(deviceResponse.getCurrentCommand(), ""));

        try {
            socket.write(deviceResponse.getRequest());
        } catch (IOException e) {
            e.printStackTrace();
        }

        return deviceResponse;
    }

    @Override
    public DeviceResponse FDSetDateTime(String date, String time) {
        StringBuilder str = new StringBuilder(date);
        str.append(" ");
        str.append(time);
        deviceResponse.setCurrentCommand(61);
        deviceResponse.setRequest(GetCustomCommand(deviceResponse.getCurrentCommand(), str.toString()));

        try {
            socket.write(deviceResponse.getRequest());
        } catch (IOException e) {
            e.printStackTrace();
        }

        return deviceResponse;
    }

    @Override
    public DeviceResponse FDGetConstants() {
        deviceResponse.setCurrentCommand(128);
        deviceResponse.setRequest(GetCustomCommand(deviceResponse.getCurrentCommand(), ""));

        try {
            socket.write(deviceResponse.getRequest());
        } catch (IOException e) {
            e.printStackTrace();
        }

        return deviceResponse;
    }

    @Override
    public DeviceResponse FDGetFirmwareInfo() {
        deviceResponse.setCurrentCommand(118);
        deviceResponse.setRequest(GetCustomCommand(deviceResponse.getCurrentCommand(), ""));

        try {
            socket.write(deviceResponse.getRequest());
        } catch (IOException e) {
            e.printStackTrace();
        }

        return deviceResponse;
    }

    @Override
    public DeviceResponse FDDailyReport(EnumConstants.EnumDailyReportType type) {
        deviceResponse.setCurrentCommand(69);
        deviceResponse.setRequest(GetCustomCommand(deviceResponse.getCurrentCommand(), type.getValue()));

        try {
            socket.write(deviceResponse.getRequest());
        } catch (IOException e) {
            e.printStackTrace();
        }

        return deviceResponse;
    }

    @Override
    public DeviceResponse FDReportByOperators() {
        deviceResponse.setCurrentCommand(105);
        deviceResponse.setRequest(GetCustomCommand(deviceResponse.getCurrentCommand(), ""));

        try {
            socket.write(deviceResponse.getRequest());
        } catch (IOException e) {
            e.printStackTrace();
        }

        return deviceResponse;
    }

    @Override
    public DeviceResponse FDReportByPLU(EnumConstants.EnumReportPLUType pluType) {
        deviceResponse.setCurrentCommand(111);
        deviceResponse.setRequest(GetCustomCommand(deviceResponse.getCurrentCommand(), pluType.getValue()));

        try {
            socket.write(deviceResponse.getRequest());
        } catch (IOException e) {
            e.printStackTrace();
        }

        return deviceResponse;
    }

    @Override
    public DeviceResponse FDReportByDPT(EnumConstants.EnumReportDepartmentType type) {
        deviceResponse.setCurrentCommand(165);
        deviceResponse.setRequest(GetCustomCommand(deviceResponse.getCurrentCommand(), type.getValue()));

        try {
            socket.write(deviceResponse.getRequest());
        } catch (IOException e) {
            e.printStackTrace();
        }

        return deviceResponse;
    }

    @Override
    public DeviceResponse FDReportByDates(String startDate, String endDate) {
        StringBuilder str = new StringBuilder(startDate);
        str.append(",");
        str.append(endDate);
        deviceResponse.setCurrentCommand(94);
        deviceResponse.setRequest(GetCustomCommand(deviceResponse.getCurrentCommand(), str.toString()));

        try {
            socket.write(deviceResponse.getRequest());
        } catch (IOException e) {
            e.printStackTrace();
        }

        return deviceResponse;
    }

    @Override
    public DeviceResponse FDStartFiscalReceipt(String operatorID, String operatorPass, String uniqueSaleNumber) {
        StringBuilder str = new StringBuilder(operatorID);
        str.append(",");
        str.append(operatorPass);
        str.append(",");
        str.append(uniqueSaleNumber);
        deviceResponse.setCurrentCommand(48);
        deviceResponse.setRequest(GetCustomCommand(deviceResponse.getCurrentCommand(), str.toString()));

        try {
            socket.write(deviceResponse.getRequest());
        } catch (IOException e) {
            e.printStackTrace();
        }

        return deviceResponse;
    }

    @Override
    public DeviceResponse FDEndFiscalReceipt() {
        deviceResponse.setCurrentCommand(56);
        deviceResponse.setRequest(GetCustomCommand(deviceResponse.getCurrentCommand(), ""));

        try {
            socket.write(deviceResponse.getRequest());
        } catch (IOException e) {
            e.printStackTrace();
        }

        return deviceResponse;
    }

    @Override
    public DeviceResponse FDSaleByPLU(String pluID, String quantity, String price, String percent, String netto, boolean toCorrectPrice) {
        StringBuilder str = new StringBuilder(toCorrectPrice ? "-" : "+");
        str.append(pluID);

        if (!quantity.isEmpty()) {
            str.append("*");
            str.append(quantity);
        }

//        if (toCorrectPrice) {
            str.append(",");
            str.append(percent);
            str.append("$");
            str.append(netto);
//        }

        deviceResponse.setCurrentCommand(58);
        deviceResponse.setRequest(GetCustomCommand(deviceResponse.getCurrentCommand(), str.toString()));

        try {
            socket.write(deviceResponse.getRequest());
        } catch (IOException e) {
            e.printStackTrace();
        }

        return deviceResponse;
    }

    @Override
    public DeviceResponse FDSaleByDPT(String deptNumber, String price, String quantity, String percent, String netto, boolean toCorrectPrice) {
        StringBuilder str = new StringBuilder(toCorrectPrice ? "-" : "+");
        str.append(deptNumber);
        str.append("@");
        str.append(price);

        if (!quantity.isEmpty()) {
            str.append("*");
            str.append(quantity);
        }

//        if (toCorrectPrice) {
            str.append(",");
            str.append(percent);
            str.append("$");
            str.append(netto);
//        }

        deviceResponse.setCurrentCommand(138);
        deviceResponse.setRequest(GetCustomCommand(deviceResponse.getCurrentCommand(), str.toString()));

        try {
            socket.write(deviceResponse.getRequest());
        } catch (IOException e) {
            e.printStackTrace();
        }

        return deviceResponse;
    }

    @Override
    public DeviceResponse FDSaleItem(String text1, String taxGroup, String price, String quantity, String percent, String netto, boolean toCorrectPrice) {
        StringBuilder str = new StringBuilder(text1);
        str.append("\t");
        str.append(taxGroup);
        str.append(toCorrectPrice ? "-" : "+");
        str.append(price);

        if (!quantity.isEmpty()) {
            str.append("*");
            str.append(quantity);
        }

//        if (toCorrectPrice) {
            str.append(",");
            str.append(percent);
            str.append("$");
            str.append(netto);
//        }

        deviceResponse.setCurrentCommand(52);
        deviceResponse.setRequest(GetCustomCommand(deviceResponse.getCurrentCommand(), str.toString()));

        try {
            socket.write(deviceResponse.getRequest());
        } catch (IOException e) {
            e.printStackTrace();
        }

        return deviceResponse;
    }

    @Override
    public DeviceResponse FDTotalSum(String text1, String text2, EnumConstants.EnumPaymentType paymentType, String amount) {
        StringBuilder str = new StringBuilder(text1);
        str.append("\n");
        str.append(text2);
        str.append("\t");
        str.append(paymentType.getValue());
        str.append(amount);

        deviceResponse.setCurrentCommand(53);
        deviceResponse.setRequest(GetCustomCommand(deviceResponse.getCurrentCommand(), str.toString()));

        try {
            socket.write(deviceResponse.getRequest());
        } catch (IOException e) {
            e.printStackTrace();
        }

        return deviceResponse;
    }

    @Override
    public DeviceResponse FDSubTotal(boolean toPrintOnPaper, boolean showOnDisplay, String percentDiscount) {
        StringBuilder str = new StringBuilder();
        str.append(toPrintOnPaper ? "1" : "0");
        str.append(showOnDisplay ? "1" : "0");
        str.append(",");
        str.append(percentDiscount);

        deviceResponse.setCurrentCommand(51);
        deviceResponse.setRequest(GetCustomCommand(deviceResponse.getCurrentCommand(), str.toString()));

        try {
            socket.write(deviceResponse.getRequest());
        } catch (IOException e) {
            e.printStackTrace();
        }

        return deviceResponse;
    }

    @Override
    public DeviceResponse FDPrintText(String text) {
        deviceResponse.setCurrentCommand(54);
        deviceResponse.setRequest(GetCustomCommand(deviceResponse.getCurrentCommand(), text));

        try {
            socket.write(deviceResponse.getRequest());
        } catch (IOException e) {
            e.printStackTrace();
        }

        return deviceResponse;
    }

    @Override
    public DeviceResponse FDPrintBuyerData(String clientID) {
        deviceResponse.setCurrentCommand(57);
        deviceResponse.setRequest(GetCustomCommand(deviceResponse.getCurrentCommand(), clientID));

        try {
            socket.write(deviceResponse.getRequest());
        } catch (IOException e) {
            e.printStackTrace();
        }

        return deviceResponse;
    }

    @Override
    public DeviceResponse FDPrintBarcode(EnumConstants.EnumBarcodeType barcodeType, String data, EnumConstants.BarcodePrintPlace printPlace) {
        StringBuilder str = new StringBuilder(barcodeType.getValue());
        str.append(data);
        str.append("\t");
        str.append(printPlace.getValue());

        deviceResponse.setCurrentCommand(84);
        deviceResponse.setRequest(GetCustomCommand(deviceResponse.getCurrentCommand(), str.toString()));

        try {
            socket.write(deviceResponse.getRequest());
        } catch (IOException e) {
            e.printStackTrace();
        }

        return deviceResponse;
    }

    @Override
    public DeviceResponse FDReceiptStatus() {
        deviceResponse.setCurrentCommand(76);
        deviceResponse.setRequest(GetCustomCommand(deviceResponse.getCurrentCommand(), "T"));

        try {
            socket.write(deviceResponse.getRequest());
        } catch (IOException e) {
            e.printStackTrace();
        }

        return deviceResponse;
    }

    @Override
    public DeviceResponse FDPrintDuplicateReceipt() {
        deviceResponse.setCurrentCommand(109);
        deviceResponse.setRequest(GetCustomCommand(deviceResponse.getCurrentCommand(), "1"));

        try {
            socket.write(deviceResponse.getRequest());
        } catch (IOException e) {
            e.printStackTrace();
        }

        return deviceResponse;
    }

    @Override
    public DeviceResponse FDCancelReceipt() {
        deviceResponse.setCurrentCommand(130);
        deviceResponse.setRequest(GetCustomCommand(deviceResponse.getCurrentCommand(), ""));

        try {
            socket.write(deviceResponse.getRequest());
        } catch (IOException e) {
            e.printStackTrace();
        }

        return deviceResponse;
    }
}
