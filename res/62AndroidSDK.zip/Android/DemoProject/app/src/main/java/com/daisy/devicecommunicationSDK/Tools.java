package com.daisy.devicecommunicationSDK;

class Tools {
    public static String convertToHex(byte[] data) {
        StringBuilder buf = new StringBuilder();
        for (byte b : data) {
            int half = (b >>> 4) & 0x0F;
            int twoHalves = 0;
            do {
                buf.append((0 <= half) && (half <= 9) ? (char) ('0' + half) : (char) ('a' + (half - 10)));
                half = b & 0x0F;
            } while (twoHalves++ < 1);
            buf.append(" ");
        }
        return buf.toString();
    }

}
