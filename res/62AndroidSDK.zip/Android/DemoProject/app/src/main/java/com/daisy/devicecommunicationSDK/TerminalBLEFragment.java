package com.daisy.devicecommunicationSDK;

import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.IBinder;
import android.os.SystemClock;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.method.ScrollingMovementMethod;
import android.text.style.ForegroundColorSpan;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

public class TerminalBLEFragment extends Fragment implements ServiceConnection, SerialListener {

    private static String TAG = "Simple BLE Terminal";

    private static String sendString;
    private FiscalDevice device;
    SharedPreferences sharedPreferences;
    private enum Connected { False, Pending, True }

    private String deviceAddress;
    private String newline = "\r\n";

    private TextView receiveText;
    private TextView sendText;
    private SerialSocketBLE socket;
    private SerialService service;
    private boolean initialStart = true;
    private Connected connected = Connected.False;

    public TerminalBLEFragment() {
    }

    /*
     * Lifecycle
     */
    @Override
    public void onCreate( Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
        setRetainInstance(true);
        deviceAddress = getArguments().getString("device");
    }

    @Override
    public void onDestroy() {
        if (connected != Connected.False)
            disconnect();
        getActivity().stopService(new Intent(getActivity(), SerialService.class));
        super.onDestroy();
    }

    @Override
    public void onStart() {
        super.onStart();
        if(service != null)
            service.attach(this);
        else
            getActivity().startService(new Intent(getActivity(), SerialService.class)); // prevents service destroy on unbind from recreated activity caused by orientation change
    }

    @Override
    public void onStop() {
        if(service != null && !getActivity().isChangingConfigurations())
            service.detach();
        super.onStop();
    }

    @SuppressWarnings("deprecation") // onAttach(context) was added with API 23. onAttach(activity) works for all API versions
    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        getActivity().bindService(new Intent(getActivity(), SerialService.class), this, Context.BIND_AUTO_CREATE);
    }

    @Override
    public void onDetach() {
        try { getActivity().unbindService(this); } catch(Exception ignored) {}
        super.onDetach();
    }

    @Override
    public void onResume() {
        super.onResume();
        if(initialStart && service !=null) {
            initialStart = false;
            getActivity().runOnUiThread(this::connect);
        }
    }

    @Override
    public void onServiceConnected(ComponentName name, IBinder binder) {
        service = ((SerialService.SerialBinder) binder).getService();
        if(initialStart && isResumed()) {
            initialStart = false;
            getActivity().runOnUiThread(this::connect);
        }
    }

    @Override
    public void onServiceDisconnected(ComponentName name) {
        service = null;
    }

    /*
     * UI
     */
    @Override
    public View onCreateView( LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_terminal, container, false);
        receiveText = view.findViewById(R.id.receive_text);                          // TextView performance decreases with number of spans
        receiveText.setTextColor(getResources().getColor(R.color.colorRecieved)); // set as default color to reduce number of spans
        receiveText.setMovementMethod(ScrollingMovementMethod.getInstance());
        sendText = view.findViewById(R.id.send_text);

        View sendBtn = view.findViewById(R.id.send_btn);
        sendBtn.setOnClickListener(v ->
        {
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putString("PASSWORD", sendString);
            editor.apply();
            device.ConfirmPasswordBLE(sendString);
        });

        View sendBtn2 = view.findViewById(R.id.send_btnExecuteCommand);
        sendBtn2.setOnClickListener(v -> device.FDMovePaper());

        View sendBtn3 = view.findViewById(R.id.send_btn3);
        sendBtn3.setOnClickListener(v -> {
            device.GetPasswordBLE();
        });

        return view;
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.menu_terminal, menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.clear) {
            receiveText.setText("");
            return true;
        } else if (id ==R.id.newline) {
            String[] newlineNames = getResources().getStringArray(R.array.newline_names);
            String[] newlineValues = getResources().getStringArray(R.array.newline_values);
            int pos = java.util.Arrays.asList(newlineValues).indexOf(newline);
            AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
            builder.setTitle("Newline");
            builder.setSingleChoiceItems(newlineNames, pos, (dialog, item1) -> {
                newline = newlineValues[item1];
                dialog.dismiss();
            });
            builder.create().show();
            return true;
        } else {
            return super.onOptionsItemSelected(item);
        }
    }

    private void connect() {
        try {
            BluetoothAdapter bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
            BluetoothDevice deviceBluetooth = bluetoothAdapter.getRemoteDevice(deviceAddress);
            String deviceName = deviceBluetooth.getName() != null ? deviceBluetooth.getName() : deviceBluetooth.getAddress();
            status("connecting...");
            connected = Connected.Pending;
            socket = new SerialSocketBLE();
            service.connect(this, "Connected to " + deviceName);
            socket.connect(getContext(), service, deviceBluetooth);

            device = new DeviceBulgaria(socket);

            sharedPreferences = getActivity().getSharedPreferences("PASSWORD", 0);

            sendString = sharedPreferences.getString("PASSWORD", "");
            if(sendString.length() > 0) {
                sendText.setText(sendString);
                device.ConfirmPasswordBLE(sendString);
                SystemClock.sleep(1000);
                device.ConfirmPasswordBLE(sendString);
            }

        } catch (Exception e) {
            onSerialConnectError(e);
        }
    }

    private void disconnect() {
        connected = Connected.False;
        service.disconnect();
        socket.disconnect();
        socket = null;
    }

    private void receive(byte[] data) {
        Log.i(TAG, "receive data length: " + data.length);
        Log.i(TAG, "receive data : " + EnumConstants.convertToHex(data));

        //Това е за паролата
        if (data.length > 4) {
            if ((data[1] > 43) && (data[3] == (byte) -57)) {
                int stamp_data_len = data.length - 16;
                byte[] stamp_data = new byte[stamp_data_len];
                System.arraycopy(data, 3, stamp_data, 0, stamp_data_len);
                stamp_data[0] = (byte) 0xc8;
                sendString = device.getResponse();
                sendText.setText(sendString);
            }
        }

        receiveText.append("DATA TO HEX: " + EnumConstants.convertToHex(data) + "\n");
        if (device.getStatus().equals(EnumErrorType.ERROR) ||
                device.getStatus().equals(EnumErrorType.ERROR_BYTE_3)) {
            receiveText.append("ERROR:" + device.getError() + "\n\n\n");
        } else {
            receiveText.append("DATA RESPONSE: " + device.getResponse() + "\n\n\n");
        }
    }

    private void status(String str) {
        SpannableStringBuilder spn = new SpannableStringBuilder(str+'\n');
        spn.setSpan(new ForegroundColorSpan(getResources().getColor(R.color.colorStatus)), 0, spn.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        receiveText.append(spn);
    }

    /*
     * SerialListener
     */
    @Override
    public void onSerialConnect() {
        status("connected");
        connected = Connected.True;
    }

    @Override
    public void onSerialConnectError(Exception e) {
        status("connection failed: " + e.getMessage());
        disconnect();
    }

    @Override
    public void onSerialRead(byte[] data) {
        device.addResponse(data);
        receive(data);
    }

    @Override
    public void onSerialIoError(Exception e) {
        status("connection lost: " + e.getMessage());
        disconnect();
    }
}
