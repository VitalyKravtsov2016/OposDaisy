package com.daisy.devicecommunicationSDK;

public enum EnumErrorType {
    NONE,
    ERROR,
    ERROR_BYTE_3
}
