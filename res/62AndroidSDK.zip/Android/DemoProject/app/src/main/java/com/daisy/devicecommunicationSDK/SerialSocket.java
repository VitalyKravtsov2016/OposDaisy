package com.daisy.devicecommunicationSDK;

import android.bluetooth.BluetoothDevice;
import android.content.Context;

import java.io.IOException;

/**
 * Interface used to connect with fiscal device.
 */
public interface SerialSocket {
    void connect(Context context, SerialListener listener, BluetoothDevice device) throws IOException;
    void write(byte[] data) throws IOException;
    void disconnect();
}
