package com.daisy.devicecommunicationSDK;

import java.util.HashMap;
import java.util.Map;

/**
 * Contains all constants, most of the enums and some of the static methods and params.
 */
public class EnumConstants {

    public static final String ERROR_NO_RESPONSE = App.getContext().getString(R.string.error_no_response);
    static final String ERROR_NO_DATA_OR_INCORRECT_INPUT = App.getContext().getString(R.string.error_incorrect_data_or_input);
    // values have to be globally unique
    static final String INTENT_ACTION_DISCONNECT = BuildConfig.APPLICATION_ID + ".Disconnect";
    static final String INTENT_CLASS_MAIN_ACTIVITY = BuildConfig.APPLICATION_ID + ".MainActivity";
    // values have to be unique within each app
    static final String NOTIFICATION_CHANNEL = BuildConfig.APPLICATION_ID + ".Channel";
    static final int NOTIFY_MANAGER_START_FOREGROUND_SERVICE = 1001;
    //CODES
    static final int CODE_GET_ERR_DESC = 0xAE;
    static final int RESPONSE_WAIT = 0x16;
    static final int RESPONSE_NAK = 0x15;
    static final int BLOCK_STX_NUM = 0x00;
    static final int BLOCK_LEN_NUM = 0x01;
    static final int BLOCK_SEQ_NUM = 0x02;
    static final int BLOCK_CMD_ID_NUM = 0x03;
    static final int TRANS_START = 0x01;
    static final int HOST_DATA_END = 0x05;
    static final int TRANS_END = 0x03;
    static final int PRN_DATA_END = 0x04;
    static final int BLOCK_BCC_SIZE = 0x04;
    static final int MIN_TRANS_SEQ = 0x20;
    static final int BLOCK_START_SIZE = 0x04;
    static final int BLOCK_SIZE = 0x01;
    static final int BLOCK_DATA_NUM = BLOCK_START_SIZE;
    static final int NUMBER_OF_SYSTEM_PARAMETERS_BULGARIA = 27;
    static final String ERROR_NOT_CORRECT_FORMAT = App.getContext().getString(R.string.error_not_correct_format);
    static final String ERROR_NOT_CORRECT_CHECKSUM = App.getContext().getString(R.string.error_not_correct_checksum);
    static final int MAX_REPEATS = 3;
    private static final int[] bytePositionNotErrors = new int[]{0, 1, 4, 8, 11, 12, 16, 17, 19, 22, 24, 32, 33, 40, 41, 42, 43, 44, 45, 46};
    public static Map<String, Integer> constants = new HashMap<>();
    static int defaultNumberOfDepartments = 50;
    static ConnectedDeviceModel currentDeviceModel;
    static int NUMBER_OF_USERS = 60;

    enum QueueType {Connect, ConnectError, Read, IoError}


    /**
     * Converts byte array to String in hex format.
     * @param data The byte array.
     *
     * @return Array in hex string.
     */
    public static String convertToHex(byte[] data) {
        StringBuilder buf = new StringBuilder();
        for (byte b : data) {
            int half = (b >>> 4) & 0x0F;
            int twoHalves = 0;
            do {
                buf.append((0 <= half) && (half <= 9) ? (char) ('0' + half) : (char) ('a' + (half - 10)));
                half = b & 0x0F;
            } while (twoHalves++ < 1);
            buf.append(" ");
        }
        return buf.toString();
    }

    /**
     * Searches for a byte target in the array.
     *
     * @param array  array to search
     * @param target target byte to search in array
     * @return True if the byte target is contained in the array
     */
    static boolean contains(byte[] array, byte target) {
        byte[] arr$ = array;
        int len$ = array.length;

        for (int i$ = 0; i$ < len$; ++i$) {
            byte value = arr$[i$];
            if (value == target) {
                return true;
            }
        }

        return false;
    }

    /**
     * Searches for a byte target in the array and output the position.
     *
     * @param array  array to search
     * @param target target byte to search in array
     * @return -1 - if the byte target is not contained in the array.
     * index - Index of the byte target in the array.
     */
    static int ByteIndexOf(byte[] array, byte target) {
        for (int i = 0; i < array.length; i++) {
            if (array[i] == target) {
                return i;
            }
        }

        return -1;
    }

    /**
     * Concatenates byte arrays into one array.
     *
     * @param arrays Arrays to concatenate.
     * @return All arrays connected in one.
     */
    static byte[] concat(byte[]... arrays) {
        int length = 0;
        byte[][] arr$ = arrays;
        int pos = arrays.length;

        for (int i$ = 0; i$ < pos; ++i$) {
            byte[] array = arr$[i$];
            length += array.length;
        }

        byte[] result = new byte[length];
        pos = 0;
        arr$ = arrays;
        int len$ = arrays.length;

        for (int i$ = 0; i$ < len$; ++i$) {
            byte[] array = arr$[i$];
            System.arraycopy(array, 0, result, pos, array.length);
            pos += array.length;
        }

        return result;
    }

    /**
     * Checks if a given string strNum is a number (works with float numbers too)
     *
     * @param strNum String to check
     * @return True if the string strNum is a number and False otherwise
     */
    static boolean isNumeric(String strNum) {
        if (strNum == null) {
            return false;
        }
        try {
            float d = Float.parseFloat(strNum);
        } catch (NumberFormatException nfe) {
            return false;
        }
        return true;
    }

    static int GetCurrentDeviceModel() {
        if (currentDeviceModel == null)
            return 0;
        switch (currentDeviceModel) {
            case EXPERT_S:
                return 16;
            case COMPACT_M:
            case COMPACT_M_RO:
            case COMPACT_S:
                return 14;
        }

        return 0;
    }

    /**
     * Enum for all the types of Reports by PLU.
     */
    public enum EnumReportPLUType {
        X("0"),
        Z("Z");
        private static final Map<String, EnumReportPLUType> stringToType = new HashMap<>();

        static {
            for (EnumReportPLUType type : EnumReportPLUType.values()) {
                stringToType.put(type.value, type);
            }
        }

        String value;

        EnumReportPLUType(String value) {
            this.value = value;
        }

        public static EnumReportPLUType getReportPLUType(String value) {
            return stringToType.get(value);
        }

        public String getValue() {
            return value;
        }
    }

    /**
     * Checks if the given number num is included in the bytePositionNotErrors.
     * If the num is included then, this is not an error.
     *
     * @param num Number to check
     * @return False if the number num is contained in bytePositionNotErrors.
     * True otherwise.
     */
    static boolean BytePositionIsError(int num) {
        int length = bytePositionNotErrors.length;
        for (int i = 0; i < length; i++) {
            if (bytePositionNotErrors[i] == num) {
                return false;
            }
        }
        return true;
    }

    /**
     * Enum for all the payment types.
     */
    public enum EnumPaymentType {
        CASH("P"),
        SALE_1("N"),
        SALE_2("C"),
        SALE_3D("D"),
        SALE_3U("U"),
        SALE_4B("B"),
        SALE_4E("E");
        private static final Map<String, EnumPaymentType> stringToType = new HashMap<>();

        static {
            for (EnumPaymentType type : EnumPaymentType.values()) {
                stringToType.put(type.value, type);
            }
        }

        String value;

        EnumPaymentType(String value) {
            this.value = value;
        }

        public static EnumPaymentType getPaymentType(String value) {
            return stringToType.get(value);
        }

        public String getValue() {
            return value;
        }
    }


    /**
     * Enum for all the kinds of daily reports.
     */
    public enum EnumDailyReportType{
        Z_REPORT("0"),
        X_REPORT("1"),
        Z_REPORT_PERIODICAL("8"),
        X_REPORT_PERIODICAL("9");

        private static final Map<String, EnumDailyReportType> stringToType = new HashMap<>();

        static {
            for (EnumDailyReportType type : EnumDailyReportType.values()) {
                stringToType.put(type.value, type);
            }
        }

        String value;

        EnumDailyReportType(String value) {
            this.value = value;
        }

        public static EnumDailyReportType getDailyReportType(String value) {
            return stringToType.get(value);
        }

        public String getValue() {
            return value;
        }
    }

    /**
     * Enum for all the type of barcode.
     */
    public enum EnumBarcodeType {
        EAH8("EAH8"),
        EAH13("EAH13"),
        CODE128("Code128"),
        UPC_E("UPC E"),
        UPC_A("UPC A"),
        STANDART_2_5("2/5 Standart"),
        INTERLEAVED_2_5("2/5 Interleaved"),
        INTERLEAVED_2_5_MOD_10("2/5 Interleaved mod10"),
        CODE39("Code39"),
        CODE39_MOD_43("Code39 mod43"),
        CODE93("Code93"),
        CODEBAR("CODEBAR"),
        POSTNET("POSTNET");

        private static final Map<String, EnumBarcodeType> stringToType = new HashMap<>();

        static {
            for (EnumBarcodeType type : EnumBarcodeType.values()) {
                stringToType.put(type.value, type);
            }
        }

        String value;

        EnumBarcodeType(String value) {
            this.value = value;
        }

        public static EnumBarcodeType getBarcodeType(String value) {
            return stringToType.get(value);
        }

        public String getValue() {
            return value;
        }
    }

    /**
     * Enum for all the places to print a barcode.
     */
    public enum BarcodePrintPlace {
        CENTER("SALE_2"),
        RIGHT("R"),
        LEFT("L");

        private static final Map<String, BarcodePrintPlace> stringToType = new HashMap<>();

        static {
            for (BarcodePrintPlace type : BarcodePrintPlace.values()) {
                stringToType.put(type.value, type);
            }
        }

        String value;

        BarcodePrintPlace(String value) {
            this.value = value;
        }

        public static BarcodePrintPlace getBarcodePrintPlace(String value) {
            return stringToType.get(value);
        }

        public String getValue() {
            return value;
        }
    }

    /**
     * Enum for all the type of reports by department.
     */
    public enum EnumReportDepartmentType {
        ONE("0"),
        ZERO("1"),
        X("X"),
        Z("Z");
        private static final Map<String, EnumReportDepartmentType> stringToType = new HashMap<>();

        static {
            for (EnumReportDepartmentType type : EnumReportDepartmentType.values()) {
                stringToType.put(type.value, type);
            }
        }

        String value;

        EnumReportDepartmentType(String value) {
            this.value = value;
        }

        public static EnumReportDepartmentType getReportDepartmentType(String value) {
            return stringToType.get(value);
        }

        public String getValue() {
            return value;
        }
    }

    /**
     * Enum for all the model devices.
     */
    public enum ConnectedDeviceModel {
        UNKNOWN("-1"),
        PERFECT_S("1"),
        PERFECT_M("2"),
        PERFECT_Z("3"),
        EXPERT_S("4"),
        ELKA_NYLA("5"),
        FUVAS_A("6"),
        BIFTU("7"),
        JX20("8"),
        COMPACT_S("9"),
        COMPACT_M("10"),
        COMPACT_M_RO("A"),
        FX1200("81"),
        FX1300("82");
       private static final Map<String, ConnectedDeviceModel> intToModel = new HashMap<>();

        static {
            for (ConnectedDeviceModel type : ConnectedDeviceModel.values()) {
                intToModel.put(type.value, type);
            }
        }

        String value;

        ConnectedDeviceModel(String value) {
            this.value = value;
        }

        public static ConnectedDeviceModel getModel(String value) {
            return intToModel.get(value);
        }

        public String getValue() {
            return value;
        }

    }

    /**
     * Enum for all the error messages.
     */
    enum ErrorBytes {        // Int Values are the places in the String !!!!!!!
        //BYTE 0
        ERROR_ALL_FIRST_3_BYTES(2, ""),
        ERROR_PRINTING_DEVICE(3, App.getContext().getString(R.string.error_printing_device)),
        //ERROR_NO_DISPLAY(4),
        ERROR_NO_DATETIME(5, App.getContext().getString(R.string.error_no_date_time)),
        ERROR_UNKNOWN_COMMAND(6, App.getContext().getString(R.string.error_unknown_command)),
        ERROR_SYNTAX(7, App.getContext().getString(R.string.error_syntax)),

        //BYTE 1
        ERROR_WRONG_PASSWORD(9, App.getContext().getString(R.string.error_wrong_pass)),
        ERROR_IN_CUTTER(10, App.getContext().getString(R.string.error_in_cutter)),
        ERROR_ZERO_RAM(13, App.getContext().getString(R.string.error_zero_ram)),
        ERROR_NOT_PERMITTED_COMMAND(14, App.getContext().getString(R.string.error_not_permitted_command)),
        ERROR_FULL_FIELDS_IN_SUMS(15, App.getContext().getString(R.string.error_full_fields)),

        //BYTE 2
        ERROR_OPENED_NON_FISCAL_RECEIPT(18, App.getContext().getString(R.string.error_opened_non_fiscal_receipt)),
        ERROR_OPENED_FISCAL_RECEIPT(20, App.getContext().getString(R.string.error_opened_fiscal_receipt)),
        ERROR_NO_PAPER_CONTROL(21, App.getContext().getString(R.string.error_no_paper_control)),
        ERROR_NO_PAPER(23, App.getContext().getString(R.string.error_no_paper)),

        //BYTE 3
        //Use Different Enum for the 3th byte.

        //BYTE 4
        ERROR_ALL_LAST_2_BYTES(34, App.getContext().getString(R.string.error_all_last_2)),
        ERROR_FULL_FP(35, App.getContext().getString(R.string.error_full_fp)),
        ERROR_LESS_THEN_50_SPACE(36, App.getContext().getString(R.string.error_less_then_50_space)),
        ERROR_WRONG_RECORD_FP(37, App.getContext().getString(R.string.error_wrong_record_in_fp)),
        ERROR_PROBLEM_WITH_TERMINAL(38, App.getContext().getString(R.string.error_problem_with_terminal)),
        ERROR_RECORDING_IN_FP(39, App.getContext().getString(R.string.error_while_writing_into_fp)),

        //BYTE 5
        ERROR_OVERFLOWED_FP(47, App.getContext().getString(R.string.error_overflowed_FP));

        private static final Map<Integer, String> intToErrorBytes = new HashMap<>();

        static {
            for (ErrorBytes type : ErrorBytes.values()) {
                intToErrorBytes.put(type.value, type.errorMessage);
            }
        }

        private int value;
        private String errorMessage;

        ErrorBytes(int value, String errorMessage) {
            this.value = value;
            this.errorMessage = errorMessage;
        }

        public static String intToErrorBytes(int value) {
            return intToErrorBytes.get(value);
        }
    }

    /**
     * Enum for all the error messages in 3th byte.
     */
    enum Errors3thByte {        // Int Values are the place in the String !!!!!!!
        //BYTE 3 ERRORS
        ERROR_OPERATION_OVERFLOW(1, App.getContext().getString(R.string.error_in_byte3_1)),
        ERROR_INCORRECT_TAX_LINK(2, App.getContext().getString(R.string.error_in_byte3_2)),
        ERROR_NOT_AUTHORIZED_TO_DO_MORE_TRANSACTIONS(3, App.getContext().getString(R.string.error_in_byte3_3)),
        ERROR_NOT_AUTHORIZED_TO_DO_MORE_PAYMENTS(4, App.getContext().getString(R.string.error_in_byte3_4)),
        ERROR_SALE_REGISTRATION_WITH_ZERO_AMOUNT(5, App.getContext().getString(R.string.error_in_byte3_5)),
        ERROR_ATTEMPT_TO_SALE_REGISTRATION_AFTER_PAYMENT_BEGAN(6, App.getContext().getString(R.string.error_in_byte3_6)),
        ERROR_NOT_AUTHORIZED_FOR_CHOSEN_OPERATION(7, App.getContext().getString(R.string.error_in_byte3_7)),
        ERROR_TAX_LINK_DISABLED(8, App.getContext().getString(R.string.error_in_byte3_8)),
        ERROR_INVOICE_NO_UNLIMITED(9, App.getContext().getString(R.string.error_in_byte3_9)),
        ERROR_WRONG_DATE_TIME(10, App.getContext().getString(R.string.error_in_byte3_10)),
        ERROR_MORE_THEN_ONE_DECIMAL_POINT_ENTERED(11, App.getContext().getString(R.string.error_in_byte3_11)),
        ERROR_TOO_MANY_PLUS_MINUSES(12, App.getContext().getString(R.string.error_in_byte3_12)),
        ERROR_PLUS_MINUS_INCORRECT_POSITION(13, App.getContext().getString(R.string.error_in_byte3_13)),
        ERROR_INCORRECT_SYMBOL(14, App.getContext().getString(R.string.error_in_byte3_14)),
        ERROR_TOO_MANY_SYMBOLS_AFTER_DECIMAL_POINT_THAN_ACCEPTED(15, App.getContext().getString(R.string.error_in_byte3_15)),
        ERROR_TOO_MANY_SYMBOLS(16, App.getContext().getString(R.string.error_in_byte3_16)),
        ERROR_TRY_TO_EXIT_REGISTER_MODE_WHEN_FISCAL_RECEIPT_IS_OPENED_BUT_NO_PAYMENT(19, App.getContext().getString(R.string.error_in_byte3_19)),
        ERROR_PRESSED_WRONG_KEY(20, App.getContext().getString(R.string.error_in_byte3_20)),
        ERROR_VALUE_OUT_OF_ACCEPTABLE_RANGE(21, App.getContext().getString(R.string.error_in_byte3_21)),
        ERROR_OPERATION_MARKUP_OR_DISCOUNT_FORBIDDEN(22, App.getContext().getString(R.string.error_in_byte3_22)),
        ERROR_OPERATION_VOID_IMPOSSIBLE(23, App.getContext().getString(R.string.error_in_byte3_23)),
        ERROR_ATTEMPT_TO_MAKE_DEEP_VOID_TO_NON_EXISTING_TRANSACTION(24, App.getContext().getString(R.string.error_in_byte3_24)),
        ERROR_ATTEMPT_TO_MAKE_PAYMENT_BEFORE_RECEIPT_IS_OPEN(25, App.getContext().getString(R.string.error_in_byte3_25)),
        ERROR_ATTEMPT_TO_SALE_A_PLU_WITH_QUANTITY_BIGGER_THAN_STOCK(26, App.getContext().getString(R.string.error_in_byte3_26)),
        ERROR_INCORRECT_COMMUNICATION_BETWEEN_ECR_AND_ELECTRONIC_SCALE(27, App.getContext().getString(R.string.error_in_byte3_27)),
        ERROR_EMPTY_NAME(29, App.getContext().getString(R.string.error_in_byte3_29)),
        ERROR_FISCAL_MEMORY_FULL(30, App.getContext().getString(R.string.error_in_byte3_30)),
        ERROR_FISCAL_MEMORY_ALMOST_FULL(31, App.getContext().getString(R.string.error_in_byte3_31)),
        ERROR_INCORRECT_BARCODE(41, App.getContext().getString(R.string.error_in_byte3_41)),
        ERROR_ATTEMPT_TO_MAKE_SALE_REGISTRATION_OR_REPORT_WITH_ZERO_BARCODE(42, App.getContext().getString(R.string.error_in_byte3_42)),
        ERROR_ATTEMPT_TO_PROGRAM_PLU_WITH_WEIGHT_TYPE_BARCODE(43, App.getContext().getString(R.string.error_in_byte3_43)),
        ERROR_ATTEMPTED_TO_SALE_OR_REPORT_WITH_NON_PROGRAMMED_BARCODE(44, App.getContext().getString(R.string.error_in_byte3_44)),
        ERROR_ATTEMPT_TO_PROGRAM_EXISTING_BARCODE(45, App.getContext().getString(R.string.error_in_byte3_45)),
        ERROR_WEIGHT_BARCODE_TOTAL(46, App.getContext().getString(R.string.error_in_byte3_46)),
        ERROR_SAME_NAME(47, App.getContext().getString(R.string.error_in_byte3_47)),
        ERROR_NOT_FOUND(50, App.getContext().getString(R.string.error_in_byte3_50)),
        ERROR_SHA1_INCORRECT_STRING(51, App.getContext().getString(R.string.error_in_byte3_51)),
        ERROR_CURRENCY_NAME_NOT_PROGRAMMED(52, App.getContext().getString(R.string.error_in_byte3_52)),
        ERROR_HEADER_NOT_PROGRAMMED(53, App.getContext().getString(R.string.error_in_byte3_53)),
        ERROR_TAX_RATES_NOT_PROGRAMMED(54, App.getContext().getString(R.string.error_in_byte3_54)),
        ERROR_CHIP_NOT_EXISTING(55, App.getContext().getString(R.string.error_in_byte3_55)),
        ERROR_SD_CARD_NOT_EMPTY(60, App.getContext().getString(R.string.error_in_byte3_60)),
        ERROR_INCORRECT_SD_CARD(61, App.getContext().getString(R.string.error_in_byte3_61)),
        ERROR_SD_CARD_FILE_NOT_FOUND(62, App.getContext().getString(R.string.error_in_byte3_62)),
        ERROR_SD_CARD_CANT_OPEN(63, App.getContext().getString(R.string.error_in_byte3_63)),
        ERROR_SD_CARD_NOT_REWRITE(64, App.getContext().getString(R.string.error_in_byte3_64)),
        ERROR_SD_CARD_WRITE_ERROR(65, App.getContext().getString(R.string.error_in_byte3_65)),
        ERROR_INCORRECT_PASSWORD(66, App.getContext().getString(R.string.error_in_byte3_66)),
        ERROR_CERTIFICATE_NOT_ENTERED(68, App.getContext().getString(R.string.error_in_byte3_68)),
        ERROR_FISCAL_MEMORY_NOT_EXIST(70, App.getContext().getString(R.string.error_in_byte3_70)),
        ERROR_INCORRECT_DATA_IN_FISCAL_MEMORY(71, App.getContext().getString(R.string.error_in_byte3_71)),
        ERROR_IN_FISCAL_MEMORY_RECORD(72, App.getContext().getString(R.string.error_in_byte3_72)),
        ERROR_FISCAL_MEMORY_SIZE(73, App.getContext().getString(R.string.error_in_byte3_73)),
        ERROR_FISCAL_MEMORY_SIZE_CHANGED(74, App.getContext().getString(R.string.error_in_byte3_74)),
        ERROR_75(75, App.getContext().getString(R.string.error_in_byte3_75)),                                   //For Ethiopia is ERROR_ANNUAL_SERVICE
        ERROR_NEED_SERVER_INFO(76, App.getContext().getString(R.string.error_in_byte3_76)),                     //For Ethiopia is ERROR_NO_SIM_CARD
        ERROR_END_COMMAND_RECEIVED(78, App.getContext().getString(R.string.error_in_byte3_78)),
        ERROR_DAILY_REPORT_SAME_DATE(79, App.getContext().getString(R.string.error_in_byte3_79)),               //For Ethiopia is ERROR_SEND_SERVER_DATA
        ERROR_OVERFLOW_MIN(80, App.getContext().getString(R.string.error_in_byte3_80)),
        ERROR_DAILY_FINANCIAL_REPORT_OVERFLOWED(81, App.getContext().getString(R.string.error_in_byte3_81)),
        ERROR_MORE_THEN_24H_FROM_FIRST_RECEIPT_WITHOUT_DAILY_Z_REPORT(82, App.getContext().getString(R.string.error_in_byte3_82)),
        ERROR_REPORT_BY_OPERATORS_OVERFLOWED(83, App.getContext().getString(R.string.error_in_byte3_83)),
        ERROR_REPORT_BY_PLU_OVERFLOWED(84, App.getContext().getString(R.string.error_in_byte3_84)),
        ERROR_PERIODIC_REPORT_OVERFLOW(85, App.getContext().getString(R.string.error_in_byte3_85)),
        ERROR_CURRENT_DATE_IS_GREATER_THAN_SERVICE_ONE(86, App.getContext().getString(R.string.error_in_byte3_86)),
        ERROR_EJT_OVERFLOWED(88, App.getContext().getString(R.string.error_in_byte3_88)),
        ERROR_OVERFLOW_MAX(89, App.getContext().getString(R.string.error_in_byte3_89)),
        ERROR_PERIODIC_Z_REPORT_NEEDED(90, App.getContext().getString(R.string.error_in_byte3_90)),
        ERROR_HAVE_TO_ISSUE_DAILY_Z_REPORT_BEFORE_EXECUTING_REQUESTED_OPERATION(91, App.getContext().getString(R.string.error_in_byte3_91)),
        ERROR_HAVE_TO_ISSUE_Z_REPORT_BY_OPERATORS_BEFORE_REQUESTED_OPERATION(92, App.getContext().getString(R.string.error_in_byte3_92)),
        ERROR_HAVE_TO_ISSUE_Z_REPORT_BY_PLU_BEFORE_REQUESTED_OPERATION(93, App.getContext().getString(R.string.error_in_byte3_93)),
        ERROR_HAVE_TO_ISSUE_Z_REPORT_BY_CATEGORY_BEFORE_REQUESTED_OPERATION(95, App.getContext().getString(R.string.error_in_byte3_95)),
        ERROR_EJT_NOT_EMPTY(96, App.getContext().getString(R.string.error_in_byte3_96)),
        ERROR_CHANGE_THE_VALUE_NOT_ALLOWED(97, App.getContext().getString(R.string.error_in_byte3_97)),
        ERROR_SAM_NOT_ACTIVE(98, App.getContext().getString(R.string.error_in_byte3_98)),
        ERROR_SAM_DIFFERENT(99, App.getContext().getString(R.string.error_in_byte3_99)),
        ERROR_SAM_NOT_EXIST(100, App.getContext().getString(R.string.error_in_byte3_100)),
        ERROR_TERMINAL_NOT_ENOUGH_SPACE(101, App.getContext().getString(R.string.error_in_byte3_101)),
        ERROR_TERMINAL_TIMEOUT(102, App.getContext().getString(R.string.error_in_byte3_102)),
        ERROR_TERMINAL_DIFFERENT(103, App.getContext().getString(R.string.error_in_byte3_103)),
        ERROR_TERMINAL_WRONG_ANSWER(104, App.getContext().getString(R.string.error_in_byte3_104)),
        ERROR_TERMINAL_SIM_CARD_LOCKED(107, App.getContext().getString(R.string.error_in_byte3_107)),
        ERROR_INCORRECT_PASSWORD_2(108, App.getContext().getString(R.string.error_in_byte3_108)),
        ERROR_HAVE_TO_ISSUE_MANUAL_TRANSFER_BEFORE_REQUESTING_OPERATION(109, App.getContext().getString(R.string.error_in_byte3_109)),
        ERROR_TERMINAL_SIM_CARD_DIFFERENT(110, App.getContext().getString(R.string.error_in_byte3_110)),
        ERROR_TERMINAL_SERVER_COMMUNICATION(111, App.getContext().getString(R.string.error_in_byte3_111)),
        ERROR_TERMINAL_SERVER_NO_PERMIT(112, App.getContext().getString(R.string.error_in_byte3_112)),
        ERROR_TERMINAL_SERVER_INCORRECT_DATA(113, App.getContext().getString(R.string.error_in_byte3_113)),
        ERROR_FTP_FILE_EXIST(114, App.getContext().getString(R.string.error_in_byte3_114)),
        ERROR_NEXUS_NEEDED(115, App.getContext().getString(R.string.error_in_byte3_115)),
        ERROR_TERMINAL_IS_NOT_EMPTY(116, App.getContext().getString(R.string.error_in_byte3_116)),
        ERROR_TERMINAL_OPERATOR_ID_COMMUNICATION(117, App.getContext().getString(R.string.error_in_byte3_117)),
        ERROR_OPERATION_FORBIDDEN(118, App.getContext().getString(R.string.error_in_byte3_118)),
        ERROR_VALUE_NOT_ENTERED(120, App.getContext().getString(R.string.error_in_byte3_120)),
        ERROR_INCORRECT_FTP_SETTINGS(121, App.getContext().getString(R.string.error_in_byte3_121)),
        ERROR_GTAPP_GET_NEAR(122, App.getContext().getString(R.string.error_in_byte3_122)),
        ERROR_SD_CARD_WRONG(123, App.getContext().getString(R.string.error_in_byte3_123)),
        ERROR_SD_CARD_CHANGED(124, App.getContext().getString(R.string.error_in_byte3_124)),
        ERROR_SD_CARD_NOT_EXIST(125, App.getContext().getString(R.string.error_in_byte3_125)),
        ERROR_SD_CARD_FULL(126, App.getContext().getString(R.string.error_in_byte3_126)),
        ERROR_SD_CARD_EMPTY(127, App.getContext().getString(R.string.error_in_byte3_127)),
        ERROR_NO_PAPER(200, App.getContext().getString(R.string.error_in_byte3_200));

        private static final Map<Integer, String> intToErrors3thByte = new HashMap<>();

        static {
            for (Errors3thByte type : Errors3thByte.values()) {
                intToErrors3thByte.put(type.value, type.errorMessage);
            }
        }

        private int value;
        private String errorMessage;

        Errors3thByte(int value, String errorMessage) {
            this.value = value;
            this.errorMessage = errorMessage;
        }

        public static String intToErrors3thBytes(int value) {
            return intToErrors3thByte.get(value);
        }
    }
}
