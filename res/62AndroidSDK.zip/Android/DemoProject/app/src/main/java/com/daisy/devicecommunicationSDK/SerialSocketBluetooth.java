package com.daisy.devicecommunicationSDK;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.ParcelUuid;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Method;
import java.util.UUID;

import static com.daisy.devicecommunicationSDK.EnumConstants.INTENT_ACTION_DISCONNECT;


public class SerialSocketBluetooth implements SerialSocket {
    private byte[] writeBuffer;
    private final IntentFilter pairingIntentFilter;
    private final BroadcastReceiver pairingBroadcastReceiver;
    private final BroadcastReceiver disconnectBroadcastReceiver;
    private Context context;
    private SerialListener listener;
    private BluetoothDevice device;
    private BluetoothSocket bSocket;
//    private boolean writePending;
    private boolean canceled;
    private boolean connected;
    private volatile boolean stopWorker;

    SerialSocketBluetooth() {
        super();
        writeBuffer = null;
        pairingIntentFilter = new IntentFilter();
        pairingIntentFilter.addAction(BluetoothDevice.ACTION_BOND_STATE_CHANGED);
        pairingIntentFilter.addAction(BluetoothDevice.ACTION_PAIRING_REQUEST);
        pairingBroadcastReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                onPairingBroadcastReceive(intent);
            }
        };
        disconnectBroadcastReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (listener != null)
                    listener.onSerialIoError(new IOException("background disconnect"));
                disconnect(); // disconnect now, else would be queued until UI re-attached
            }
        };

    }

    public void connect(Context context, SerialListener listener, BluetoothDevice device) throws IOException {
        canceled = false;
        this.context = context;
        this.listener = listener;
        context.registerReceiver(disconnectBroadcastReceiver, new IntentFilter(INTENT_ACTION_DISCONNECT));
//        Log.d(TAG, "connect " + device);
        context.registerReceiver(pairingBroadcastReceiver, pairingIntentFilter);

        try {
            if (device == null)
                return;
            ParcelUuid[] allUuid = device.getUuids();
            if (bSocket == null ||
                    !this.device.equals(device)) {
                if (bSocket != null) {
                    InputStream inStream = bSocket.getInputStream();
                    inStream.close();
                    OutputStream outStream = bSocket.getOutputStream();
                    outStream.close();
                    bSocket.close();
                    bSocket = null;
                    device = null;
                }

                UUID uuid = null;

                for (ParcelUuid id :
                        allUuid) {

                    if (id.getUuid().toString().toUpperCase().equals("00001101-0000-1000-8000-00805F9B34FB")) {
                        uuid = id.getUuid();
                        break;
                    }
                }

                if (uuid == null) {
                    uuid = allUuid[0].getUuid();
                }

                try {
                    final Method m = device.getClass().getMethod("createInsecureRfcommSocketToServiceRecord", UUID.class);
                    BluetoothSocket socket = (BluetoothSocket) m.invoke(device, uuid);
                    this.device = device;
                    bSocket = socket;
                } catch (Exception e) {
                    this.device = device;
                    bSocket = device.createRfcommSocketToServiceRecord(uuid);
                }

                try {
                    if (bSocket != null && !bSocket.isConnected()) {
                        bSocket.connect();
                        connected = true;
                        canceled = false;
                        onSerialConnect();
                        beginListenForData();
                    }
                } catch (IOException e) {
                    e.printStackTrace();

                    try {
                        if (bSocket != null) {
                            bSocket.getInputStream().close();
                            bSocket.getOutputStream().close();
                            bSocket.close();
                        }
                    } catch (IOException e1) {
                        e1.printStackTrace();
                    }

                    canceled = true;
                    connected = false;
                    bSocket = null;
                    this.device = null;
                }

            }
        } catch (IOException e) {
            e.printStackTrace();
            canceled = true;
            connected = false;
        }

    }

    public void write(byte[] data) throws IOException {
        if (canceled || !connected)
            throw new IOException("not connected");

//        byte[] data0;
//        synchronized (writeBuffer) {
//            data0 = data;
//
//            if (!writePending && writeBuffer.isEmpty()) {
//                writePending = true;
//            } else {
//                writeBuffer.add(data0);
//                data0 = null;
//            }
//        }
//
//        if (data0 != null) {
            OutputStream os = bSocket.getOutputStream();
            os.write(data);
//            writePending = false;
//        }
    }

    private void onPairingBroadcastReceive(Intent intent) {
        String action = intent.getAction();

        switch (action) {
            //When the device is disconnected.
            case BluetoothDevice.ACTION_ACL_DISCONNECTED:
                try {
                    if (bSocket != null) {
                        bSocket.getInputStream().close();
                        bSocket.getOutputStream().close();
                        bSocket.close();

                        bSocket = null;
                        this.device = null;
                    }
                } catch (IOException | NullPointerException e) {
                    e.printStackTrace();
                }
                break;
            // This happens when a new device is paired.
//            case BluetoothDevice.ACTION_BOND_STATE_CHANGED:
//                BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
//                if (device.getBondState() == BluetoothDevice.BOND_BONDED) {
//                    String deviceBTName = device.getName();
//                    String deviceBTMajorClass
//                            = getBTMajorDeviceClass(device
//                            .getBluetoothClass()
//                            .getMajorDeviceClass());
//
//                    //Add device in the Paired List View.
//                    pairedBtArrayAdapter.add(new LineMenu(deviceBTName,
//                            device.getAddress(),
//                            deviceBTMajorClass,
//                            LineMenu.TypeOfDevices.permissiveValueOf(deviceBTMajorClass)));
//                    bdDevices.add(device);
////                        lineMenuAdapterPaired.notifyDataSetChanged();
//
//                    //Remove device in the Founded bluetooth devices.
//                    int btArrayAdapterSize = newBtArrayAdapter.size();
//                    for (int i = 0; i < btArrayAdapterSize; i++) {
//                        if (newBtArrayAdapter.get(i).getAddress().equals(device.getAddress())) {
//                            newBtArrayAdapter.remove(i);
//                            break;
//                        }
//                    }
////                        lineMenuAdapterUnPaired.notifyDataSetChanged();
//                }
//                break;
            //This happens when the Bluetooth State is Changed.
            case BluetoothAdapter.ACTION_STATE_CHANGED:
                final int state = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE,
                        BluetoothAdapter.ERROR);
                switch (state) {
                    case BluetoothAdapter.STATE_OFF:
                        if (bSocket != null) {
                            try {
                                bSocket.close();
                            } catch (IOException e1) {
                                e1.printStackTrace();
                            }
                            bSocket = null;
                            this.device = null;
                        }
                        break;
                    case BluetoothAdapter.STATE_TURNING_OFF:
                        break;
                    case BluetoothAdapter.STATE_ON:
                        break;
                    case BluetoothAdapter.STATE_TURNING_ON:
                        break;
                }
                break;
            //This happens when new bluetooth device is found
//            case BluetoothDevice.ACTION_FOUND:
//                BluetoothDevice device2 = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
//                String deviceBTMajorClass =
//                        getBTMajorDeviceClass(device2
//                                .getBluetoothClass()
//                                .getMajorDeviceClass());
//
//                String devName = "No Name";
//                if (device2.getName() != null) {
//                    devName = device2.getName();
//                }
//
//                if (pairedBtArrayAdapter.size() == 0) {
//                    bdDevices.add(device2);
//                    lineMenuAdapterUnPaired.add(new LineMenu(devName,
//                            device2.getAddress(),
//                            deviceBTMajorClass,
//                            LineMenu.TypeOfDevices.permissiveValueOf(deviceBTMajorClass)));
//                } else {
//                    boolean isPaired = false;
//                    for (LineMenu line : pairedBtArrayAdapter) {
//                        if (line.getAddress().equals(device2.getAddress())) {
//                            isPaired = true;
//                        }
//                    }
//
//                    for (LineMenu line : newBtArrayAdapter) {
//                        if (line.getAddress().equals(device2.getAddress())) {
//                            isPaired = true;
//                        }
//                    }
//
//                    if (!isPaired) {
//                        bdDevices.add(device2);
//                        lineMenuAdapterUnPaired.add(new LineMenu(
//                                devName,
//                                device2.getAddress(),
//                                deviceBTMajorClass,
//                                LineMenu.TypeOfDevices.permissiveValueOf(deviceBTMajorClass)));
//                    }
//                }
//                break;
        }
    }

    public void disconnect() {
        listener = null; // ignore remaining data and errors
        device = null;
        canceled = true;

        if (bSocket != null) {
            try {
                bSocket.close();
            } catch (Exception ignored) {
            }
            bSocket = null;
            connected = false;
        }
        try {
            context.unregisterReceiver(pairingBroadcastReceiver);
        } catch (Exception ignored) {
        }
        try {
            context.unregisterReceiver(disconnectBroadcastReceiver);
        } catch (Exception ignored) {
        }
    }

    private void onSerialConnect() {
        if (listener != null)
            listener.onSerialConnect();
    }

    private void onSerialConnectError(Exception e) {
        canceled = true;
        if (listener != null)
            listener.onSerialConnectError(e);
    }

    private void onSerialRead(byte[] data) {
        if (listener != null)
            listener.onSerialRead(data);
    }

    private void onSerialIoError(Exception e) {
//        writePending = false;
        canceled = true;
        if (listener != null)
            listener.onSerialIoError(e);
    }

    void beginListenForData() {
        stopWorker = false;
        writeBuffer = null;
        Thread workerThread = new Thread(() -> {
            while (!Thread.currentThread().isInterrupted() && !stopWorker) {
                try {
                    int bytesAvailable = bSocket.getInputStream().available();
                    if (bytesAvailable > 0) {

                        byte[] packetBytes = new byte[bytesAvailable];
                        bSocket.getInputStream().read(packetBytes);

                        if(bytesAvailable > 1 && packetBytes[0] != 0x16 && packetBytes[0] != 0x15) {
                            if (EnumConstants.contains(packetBytes, (byte) EnumConstants.TRANS_START) &&
                                    EnumConstants.contains(packetBytes, (byte) EnumConstants.HOST_DATA_END) &&
                                    EnumConstants.contains(packetBytes, (byte) EnumConstants.TRANS_END)) {
                                onSerialRead(packetBytes);
                            } else {  //not full packet is received.
                                if (writeBuffer == null) {
                                    writeBuffer = packetBytes;
                                } else {
                                        byte[] tmp = writeBuffer;

                                        writeBuffer = new byte[tmp.length + packetBytes.length];

                                        System.arraycopy(tmp, 0, writeBuffer, 0, tmp.length);
                                        System.arraycopy(packetBytes, 0, writeBuffer, tmp.length, packetBytes.length);
                                }

                                if (EnumConstants.contains(writeBuffer, (byte) EnumConstants.TRANS_START) &&
                                        EnumConstants.contains(writeBuffer, (byte) EnumConstants.HOST_DATA_END) &&
                                        EnumConstants.contains(writeBuffer, (byte) EnumConstants.TRANS_END)) {
                                    onSerialRead(writeBuffer);
                                    writeBuffer = null;
                                }
                            }
                        }
                    }
                } catch (IOException ex) {
                    stopWorker = true;
                    onSerialIoError(ex);
                }
            }
        });

        workerThread.start();
    }
}
