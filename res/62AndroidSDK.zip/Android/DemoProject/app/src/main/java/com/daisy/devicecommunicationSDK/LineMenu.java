package com.daisy.devicecommunicationSDK;

class LineMenu {
    private String title;
    private String address;
    private TypeOfDevices typeOfDevices;
    private boolean isSelected;

    LineMenu(String title, String address, String message, TypeOfDevices typeOfDevices) {
        this.title = title;
        this.typeOfDevices = typeOfDevices;
        this.address = address;
    }

    LineMenu()
    {
        isSelected = false;
    }

    private static int typeOfDeviceDrawable(TypeOfDevices typeOfDevices) {
//        switch (typeOfDevices) {
//            case AUDIO_VIDEO:
//                return R.drawable.img_audio;
//            case COMPUTER:
//                return R.drawable.img_computer;
//            case PHONE:
//                return R.drawable.img_phone;
//            case TOY:
//            case IMAGING:
//            case UNCATEGORIZED:
//            case PRINTER:
//                return android.R.drawable.ic_menu_gallery;
//        }

        return R.drawable.bluetooth;
    }

    String getTitle() {
        return title;
    }

    String getAddress() {
        return address;
    }

    int getAssociatedDrawable() {
        return typeOfDeviceDrawable(typeOfDevices);
    }

    public boolean isSelected() {
        return isSelected;
    }

    public void setSelected(boolean selected) {
        isSelected = selected;
    }

    enum TypeOfDevices {
        PRINTER, AUDIO_VIDEO, COMPUTER, IMAGING, PHONE, TOY, UNCATEGORIZED;

        public static TypeOfDevices permissiveValueOf(String name) {
            for (TypeOfDevices e : values()) {
                if (e.name().equals(name)) {
                    return e;
                }
            }
            return UNCATEGORIZED;
        }
    }
}
