package com.daisy.devicecommunicationSDK;

class DeviceResponse {
    private int currentCommand;
    private String error;
    private byte[] responseByte;
    private String response;
    private byte[] request;
    private EnumErrorType status;
    private byte[] arrayByte3;

    DeviceResponse(int currentCommand, String error, String response, byte[] request, byte[] arrayByte3, EnumErrorType status) {
        this.currentCommand = currentCommand;
        this.error = error;
        this.response = response;
        this.request = request;
        this.status = status;
        this.arrayByte3 = arrayByte3;
    }

    DeviceResponse() {
        currentCommand = 0x00;
        error = "";
        response = "";
        request = null;
        status = EnumErrorType.NONE;
        arrayByte3 = null;
    }

    void addResponse(byte[] bytes){
        if(responseByte == null){
            responseByte = bytes;
        }else {
            byte[] old = responseByte;
            responseByte = new byte[old.length + bytes.length];

            System.arraycopy(old, 0, responseByte, 0, old.length);
            System.arraycopy(bytes, 0, responseByte, old.length, bytes.length);

        }
    }

    private void clearResponse(){
        responseByte = null;
        response = "";
    }

    byte[] GetResponseByte(){
        return responseByte;
    }

    String getResponse(){
        return response;
    }

    void setResponse(String response) {
        this.response = response;
    }

    int getCurrentCommand() {
        return currentCommand;
    }

    void setCurrentCommand(int currentCommand) {
        this.currentCommand = currentCommand;
    }

    String getError() {
        return error;
    }

    void setError(String error) {
        setStatus(EnumErrorType.ERROR);
        this.error = error;
    }

    void addError(String error) {
        setStatus(EnumErrorType.ERROR);
        this.error += error;
    }

    void clearError(){
        setStatus(EnumErrorType.NONE);
        error = "";
    }

    void appendError(String error) {
        this.error += error;
    }

    byte[] getRequest() {
        return request;
    }

    void setRequest(byte[] request) {
        clearResponse();
        clearError();
        this.request = request;
    }

    EnumErrorType getStatus() {
        return status;
    }

    void setStatus(EnumErrorType errorStatus) {
        status = errorStatus;
    }

    byte[] getArrayByte3() {
        return arrayByte3;
    }

    void setArrayByte3(byte[] arrayByte3) {
        this.arrayByte3 = arrayByte3;
    }
}
