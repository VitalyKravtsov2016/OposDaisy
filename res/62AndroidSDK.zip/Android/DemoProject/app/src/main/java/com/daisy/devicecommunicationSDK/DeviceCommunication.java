package com.daisy.devicecommunicationSDK;

import java.io.UnsupportedEncodingException;
import java.util.Arrays;
import java.util.Calendar;

import static com.daisy.devicecommunicationSDK.EnumConstants.BLOCK_SIZE;
import static com.daisy.devicecommunicationSDK.EnumConstants.ByteIndexOf;
import static com.daisy.devicecommunicationSDK.EnumConstants.MIN_TRANS_SEQ;
import static com.daisy.devicecommunicationSDK.EnumConstants.contains;

class DeviceCommunication {
    private byte[] errorByte3;
    //Class variables.
    private int transSeq;

    //Constructors.
    DeviceCommunication() {
        transSeq = MIN_TRANS_SEQ;
        errorByte3 = null;
    }

    /**
     * Add the first 4 bytes in the lpBuf array.
     *
     * @param lpBuf Array that will be modify.
     * @param CmdID The ID of the command that will be send.
     * @param nLen  Size of the array. (include the first 4 bytes and the command length)
     */
    private void MakeTransStart(char[] lpBuf, int CmdID, int nLen) {
        if (lpBuf.length <= 0)
            return;

        lpBuf[EnumConstants.BLOCK_STX_NUM] = (char) EnumConstants.TRANS_START;
        lpBuf[EnumConstants.BLOCK_LEN_NUM] = (char) (0x20 + nLen);

        Calendar c = Calendar.getInstance();
        if (transSeq >= 255) {
            transSeq = MIN_TRANS_SEQ + 1;
        } else if ((transSeq == 0)) {
            int h = c.get(Calendar.HOUR);
            int sec = c.get(Calendar.SECOND);
            int minSeq = MIN_TRANS_SEQ + 1;

            transSeq = minSeq + h + sec;
        } else {
            transSeq++;
        }

        lpBuf[EnumConstants.BLOCK_SEQ_NUM] = (char) (transSeq);
        lpBuf[EnumConstants.BLOCK_CMD_ID_NUM] = (char) CmdID;
    }

    /**
     * Add the end byte for the command, the check sum, and the end byte of the array.
     *
     * @param lpBuf Array that will be modify.
     * @param nLen  Current position in the array.
     * @return Makes Check sum and returns the lenght of the char array.
     */
    private int MakeTransEnd(char[] lpBuf, int nLen) {
        if (lpBuf.length <= 0 || nLen < 0)
            return 0;

        lpBuf[nLen++] += EnumConstants.HOST_DATA_END;
        int BCC = MakeBCC(lpBuf, nLen);
        PutBCC(BCC, lpBuf, nLen);
        nLen += EnumConstants.BLOCK_BCC_SIZE;
        lpBuf[nLen] = EnumConstants.TRANS_END;

        return nLen;
    }

    /**
     * Makes the Check Sum for the array.
     *
     * @param lpStr Array, which is necessary in order to create the check sum
     * @param iLen  Length of the array.
     * @return The check sum of the lpStr array.
     */
    private int MakeBCC(char[] lpStr, int iLen) {
        if (lpStr.length <= 1)
            return 0;

        int iWrk;
        int nCount = 0;
        for (iWrk = 1; iWrk < iLen; iWrk++) {
            nCount += (int) lpStr[iWrk];
        }

        return (nCount);
    }

    /**
     * Puts check sum in the array.
     *
     * @param bcc  The Check sum.
     * @param buff Array, in which the check sum will be added.
     * @param len  Current length of the array.
     */
    private void PutBCC(int bcc, char[] buff, int len) {
        if (buff.length <= 0)
            return;

        for (int i = EnumConstants.BLOCK_BCC_SIZE - 1; i >= 0; i--) {
            buff[i + len] += ((bcc & 0x0F) + 0x30);
            bcc = bcc >> 4;
        }
    }

    byte[] GetByteArray(StringBuilder data, int code) {
        char[] trans = new char[1024];
        int wIndex = 0x04;    // start address of data bytes

        byte[] bytes = new byte[300];
        try {
            bytes = data.toString().getBytes("cp1251");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }

        int lengthBytes = bytes.length;
        for (int i = 0; i < lengthBytes; i++) {
            if (bytes[i] < 0) {
                trans[wIndex] = (char) ((int) bytes[i] + 256);
            } else {
                trans[wIndex] = (char) bytes[i];
            }
            wIndex++;
        }

        MakeTransStart(trans, code, wIndex);
        wIndex = MakeTransEnd(trans, wIndex);

        byte[] result = new byte[wIndex + 1];
        int lengthResult = result.length;
        for (int i = 0; i < lengthResult; i++) {
            result[i] = (byte) trans[i];
        }

        return result;
    }

    /**
     * Reads the response and extract data from it.
     *
     * @param deviceResponse Device response class.
     * @throws UnsupportedEncodingException If cannot encode the data.
     */
    void AddData(DeviceResponse deviceResponse) throws UnsupportedEncodingException {
        byte[] receivedData = deviceResponse.GetResponseByte();
        String data;
        if (!contains(receivedData, (byte) EnumConstants.TRANS_START) ||
                !contains(receivedData, (byte) EnumConstants.TRANS_END) ||
                !contains(receivedData, (byte) EnumConstants.PRN_DATA_END) ||
                !contains(receivedData, (byte) EnumConstants.HOST_DATA_END) ||
                ByteIndexOf(receivedData, (byte) EnumConstants.TRANS_END) - ByteIndexOf(receivedData, (byte) EnumConstants.HOST_DATA_END) - 1 != 4) {
            deviceResponse.setError(EnumConstants.ERROR_NOT_CORRECT_FORMAT);
            return;
        }

        byte[] checkSum = Arrays.copyOfRange(receivedData,
                ByteIndexOf(receivedData, (byte) EnumConstants.HOST_DATA_END) + 1,
                ByteIndexOf(receivedData, (byte) EnumConstants.TRANS_END));
        int nDataLen = ByteIndexOf(receivedData, (byte) EnumConstants.HOST_DATA_END) - ByteIndexOf(receivedData, (byte) EnumConstants.TRANS_START);

        if ((byte) nDataLen != (byte) (receivedData[BLOCK_SIZE] - 0x20)) {
            //without + because it can show two times. ^
            deviceResponse.setError(EnumConstants.ERROR_NOT_CORRECT_FORMAT);
            return;
        }

        byte[] dataToEnd = Arrays.copyOfRange(receivedData, 1, ByteIndexOf(receivedData, (byte) EnumConstants.HOST_DATA_END) + 1);

        //Check Sum.
        int BCC = 0;

        for (byte aDataToEnd : dataToEnd) {
            if (aDataToEnd < 0) {
                BCC += aDataToEnd & 0xFF;
            } else {
                BCC += aDataToEnd;
            }
        }

        char[] buff = String.format("%04X", BCC).toCharArray();
        for (int i = 0; i < 4; i++) {
            if (buff[i] > '9') {
                buff[i] -= 0x07;
            }

            if (checkSum[i] != buff[i]) {
                deviceResponse.setError(EnumConstants.ERROR_NOT_CORRECT_CHECKSUM);
                return;
            }
        }

        //Check Status.
        byte[] status = Arrays.copyOfRange(receivedData,
                ByteIndexOf(receivedData, (byte) EnumConstants.PRN_DATA_END) + 1,
                ByteIndexOf(receivedData, (byte) EnumConstants.HOST_DATA_END));

        String bytesToBits = "";
        for (byte b1 : status) {
            bytesToBits += String.format("%8s", Integer.toBinaryString(b1 & 0xFF)).replace(' ', '0');
        }

        String error = CheckForErrors(bytesToBits.toCharArray());
        if(error != null && !error.isEmpty()) {
            deviceResponse.addError(error);
        }

        if(errorByte3 != null && errorByte3.length > 0){
            deviceResponse.setArrayByte3(errorByte3);
            deviceResponse.setStatus(EnumErrorType.ERROR_BYTE_3);
        }

        data = new String(Arrays.copyOfRange(receivedData,
                EnumConstants.BLOCK_DATA_NUM,
                ByteIndexOf(receivedData, (byte) EnumConstants.PRN_DATA_END)),
                "Windows-1251");

        deviceResponse.setResponse(data);
    }

    /**
     * Check array for errors.
     *
     * @param arrayChars The array, which will be checked for errors
     * @return Returns the error message.
     */
    private String CheckForErrors(char[] arrayChars) {
        String isError = "";
        errorByte3 = null;
        int length = arrayChars.length;
        for (int i = 0; i < length; i++) {
            if (arrayChars[i] == '1' && i % 8 != 0 && EnumConstants.ErrorBytes.intToErrorBytes(i) != null) {
                isError += EnumConstants.ErrorBytes.intToErrorBytes(i) + "\n";
            } else if (arrayChars[i] == '1' && EnumConstants.BytePositionIsError(i)) {
                isError += App.getContext().getString(R.string.error_unknown_in_byte) + String.valueOf(i) + ".";
            }
        }

        //Взимаме 7-те байта за да разберем каква е грешката, ако е в 3-тия байт на съобщението.
        if (new String(arrayChars).substring(25, 32).contains("1")) {
            String code = new String(arrayChars).substring(25, 32);
            int dec = Integer.parseInt(code, 2);

            byte[] array = GetErrorMessage(dec);
            errorByte3 = Arrays.copyOf(array, array.length);
            isError = EnumConstants.Errors3thByte.intToErrors3thBytes(dec);
        }
        return isError;
    }

    private byte[] GetErrorMessage(int dec) {
        return GetByteArray(new StringBuilder(dec), EnumConstants.CODE_GET_ERR_DESC);
    }
}
