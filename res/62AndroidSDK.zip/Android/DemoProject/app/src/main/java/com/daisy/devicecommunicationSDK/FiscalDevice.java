package com.daisy.devicecommunicationSDK;

import java.io.UnsupportedEncodingException;

/**
 * Base abstract class for fiscal device. Contains all the commands and reponse from the device.
 */
public abstract class FiscalDevice {

    /**
     * @return Returns information about last response.
     */
    DeviceResponse getDeviceResponse() {
        return deviceResponse;
    }

    private DeviceResponse deviceResponse;
    DeviceCommunication deviceCommunication;

    FiscalDevice() {
        deviceResponse = new DeviceResponse();
    }

    /**
     * @return Returns last command error.
     */
    String getError(){
        return deviceResponse.getError();
    }

    /**
     * @return Returns last command request array.
     */
    byte[] getRequest(){
        return deviceResponse.getRequest();
    }

    /**
     * Stacks the response from the device.
     * @param bytes Current part of the response that is received.
     */
    void addResponse(byte[] bytes){
        deviceResponse.addResponse(bytes);
    }

    /**
     * @return Returns converted response as string.
     */
    String getResponse() {
        try {
            deviceCommunication.AddData(deviceResponse);
            if(getStatus().equals(EnumErrorType.ERROR) || getStatus().equals(EnumErrorType.ERROR_BYTE_3)){
                return getError();
            }else {
                return deviceResponse.getResponse();
            }
        } catch (UnsupportedEncodingException e) {
            return "UNKNOWN ERROR...";
        }
    }

    /**
     * @return Returns status of lat command.
     */
    EnumErrorType getStatus(){
        return deviceResponse.getStatus();
    }

    /**
     * Requests a password from the device. This have to be called on every first connection with a device through BLE.<br>
     * After receiving a response, use it by calling ConfirmPasswordBLE(password) to confirm the password and establish <br>
     * connection with the device.
     */
    public abstract void GetPasswordBLE();

    /** Used after GetPasswordBLE() to confirm password and establish connection with device.
     * @param pass Password to send to device.
     */
    public abstract void ConfirmPasswordBLE(String pass);

    /**
     * Moves paper with one line
     *
     * @return DeviceResponse: Contains information about the operation (errors, response, request etc.)
     */
    public abstract DeviceResponse FDMovePaper();

    /**
     * Get last issued document number.
     *
     * @return DeviceResponse: Contains information about the operation (errors, response, request etc.)<br><br>
     *
     * Command Response:<br>
     *         DocNumber ( Example: 0001)
     */
    public abstract DeviceResponse FDGetLastDocNumber();

    /**
     * Get Status of the device.
     *
     * Command Response:
     *         {S0}{S1}{S2}{S3}{S4}{S5}
     *
     * @return DeviceResponse: Contains information about the operation (errors, response, request etc.)<br><br>
     * Command Response:<br>
     *         {S0}{S1}{S2}{S3}{S4}{S5}
     */
    public abstract DeviceResponse FDGetStatus();

    /**
     * NOT DONE.
     * @return DeviceResponse: Contains information about the operation (errors, response, request etc.)
     */
    public abstract DeviceResponse FDGetFinalRecord();

    /**
     * The Fiscal device prints the diagnostic information.
     *
     * @return DeviceResponse: Contains information about the operation (errors, response, request etc.)
     */
    public abstract DeviceResponse FDGetDiagnosticInfo();

    /**
     * Get tax rates.

     * @return DeviceResponse: Contains information about the operation (errors, response, request etc.)<br><br>
     *
     *     Command Response:<br>
     *         Tax1,Tax2,Tax3,Tax4,Tax5,Tax6,Tax7,Tax8
     */
    public abstract DeviceResponse FDGetTaxRates();

    /**
     * Add PLU with specified number. Replaces current one if the PLU number exists.
     *
     * @param taxGroup  Tax Group: Example - А, Б, В, Г, ... (Cyrillic)
     * @param pluNumber PLU Number: Example - 1,2,3,4,5...
     * @param price Price of the PLU: Example - 1.00, 14, 16.37, ...
     * @param name Name of the PLU
     * @param barcode Barcode of the PLU. Up to 13 bytes in ASCII format: Example (0x33 0x38 0x30 0x30 0x30 0x30 0x31 0x31 0x30 0x31 0x38 0x31 0x35)
     * @param department Department number that the PLU is in. Example - 1,2,3,4,5...
     * @param stockQuantity Stock quantity of the PLU.
     *
     * @return DeviceResponse: Contains information about the operation (errors, response, request etc.)<br><br>
     *
     *     Command Response:<br>
     *       CASH - Command is successful.<br>
     *       F - Command is unsuccessful.
     */
    public abstract DeviceResponse FDProgramPLU(String taxGroup, String pluNumber, String price, String name, String barcode, String department, String stockQuantity);

    /**
     * Reads the PLU with id pluNumber.
     *
     * @param pluNumber PLU Number. Example - 1,2,3,4,5...
     *
     * @return DeviceResponse: Contains information about the operation (errors, response, request etc.)<br><br>
     *
     * Command Response:<br>
     *         CASH,PLU,Time,TaxGroup,UnitPrice,Amount,Total,Name 0x0A BARCODE,Dept,1,StockQty
     */
    public abstract DeviceResponse FDReadPLU(String pluNumber);
    /**
     * Reads the first PLU that is found.
     *
     * @return DeviceResponse: Contains information about the operation (errors, response, request etc.)<br><br>
     *
     * Command Response:<br>
     *         CASH,PLU,Time,TaxGroup,UnitPrice,Amount,Total,Name 0x0A BARCODE,Dept,1,StockQty
     */
    public abstract DeviceResponse FDReadFirstPLU();

    /**
     * Reads next PLU after FDReadFirstPLU() is called.<br>
     * IMPORTANT: Command FDReadFirstPLU must be called first.
     *
     * @return DeviceResponse: Contains information about the operation (errors, response, request etc.)<br><br>
     *
     * Command Response:<br>
     *         CASH,PLU,Time,TaxGroup,UnitPrice,Amount,Total,Name 0x0A BARCODE,Dept,1,StockQty
     */
    public abstract DeviceResponse FDReadNextPLU();

    /** Deletes the PLU with id pluNumber.
     *
     * @param pluNumber PLU Number.
     *
     * @return DeviceResponse: Contains information about the operation (errors, response, request etc.)<br><br>
     *
     * Command Response:<br>
     *         CASH,PLU_count (PLU_count - number of free PLU) - Command is successful.<br>
     *         F - Command is unsuccessful.
     */
    public abstract DeviceResponse FDDeletePLU(String pluNumber);

    /**
     * Program department.<br><br>
     *
     *     IMPORTANT: Department cannot be changed if there are payments for that department or tax group, before making Z report.<br>
     *     Check the error and make the necessary Z report.
     *
     * @param deptNumber Number of the department.
     * @param name Name of the department.
     * @param taxGroup Tax group.
     * @param maxDigits Max number of digits when working with free price when working with that department. Default is "0".
     *
     * @return DeviceResponse: Contains information about the operation (errors, response, request etc.)
     */
    public abstract DeviceResponse FDProgramDPT(String deptNumber, String name, String taxGroup, String maxDigits);

    /**
     * Reads department.
     *
     * @param deptNumber Department number.
     *
     * @return DeviceResponse: Contains information about the operation (errors, response, request etc.)<br><br>
     *
     * Command Response:<br>
     *         CASH,DeptNum,Name 0x0A TaxGroup,Price,Amount,Total,PerAmount,PerTotal,MaxDigits - Command is successful.<br>
     *         F - Command is unsuccessful.
     */
    public abstract DeviceResponse FDReadDPT(String deptNumber);

    /**
     * Get date and time.
     *
     * @return DeviceResponse: Contains information about the operation (errors, response, request etc.)<br><br>
     *
     * Command Response:<br>
     *         DD–MM–YY HH:mm:SS
     */
    public abstract DeviceResponse FDGetDateTime();

    /**
     * Set Date and Time.
     *
     * @param date Date Format - DD–MM–YY.
     * @param time Time Format - HH:mm:SS.
     *
     * @return DeviceResponse: Contains information about the operation (errors, response, request etc.)
     */
    public abstract DeviceResponse FDSetDateTime(String date, String time);

    /**<br>
     * Get Constants.
     *
     * @return DeviceResponse: Contains information about the operation (errors, response, request etc.)<br><br>
     *
     * Command Response:<br>
     *         P1,P2,......,P25<br><br>
     *
     * P1 Horizontal size of the graphic logo in pixels.<br>
     * P2 Vertical size of graphic logo in pixels.<br>
     * P3 Number of different payments.<br>
     * P4 Number of tax groups.<br>
     * P5 Not in use.<br>
     * P6 Not in use.<br>
     * P7 Symbol for first tax group.<br>
     * P8 Size of inside arithmetic.<br>
     * P9 Number of symbols in one line.<br>
     * P10 Number of symbols in on comment line.<br>
     * Р11 Size (Number of symbols) of the names(operators, PLU, departments).<br>
     * Р12 Size (Number of symbols) of identifying number of device.<br>
     * Р13 Size (Number of symbols) of number of fiscal memory.<br>
     * Р14 Size (Number of symbols) of tax number: 0.<br>
     * Р15 Size (Number of symbols) of TIN (EIK).<br>
     * Р16 Number of departments.<br>
     * Р17 Number of PLU.<br>
     * Р18 Flag for field stock quantity in PLU data (0 or 1).<br>
     * Р19 Flag for field barcode in PLUD data (0 or 1).<br>
     * Р20 Number of stock groups.<br>
     * Р21 Number of operators.<br>
     * Р22 Size (Number of symbols) of customer names.Дължина (Брой символи) на имена на плащания<br>
     * Р23 Not in use (0).<br>
     * Р24 Not in use (0).<br>
     * Р25 Not in use (0).
     */
    public abstract DeviceResponse FDGetConstants();

    /**
     * @return DeviceResponse: Contains information about the operation (errors, response, request etc.)
     */
    public abstract DeviceResponse FDGetFirmwareInfo();

    /**
     * Makes Daily Report.
     *
     * @param type Type of the report. Possible values:<br>
 *             Z REPORT<br>
     *         X REPORT<br>
     *         PERIODICAL Z REPORT<br>
     *         PERIODICAL X REPORT
     *
     * @return DeviceResponse: Contains information about the operation (errors, response, request etc.)<br><br>
     *
     *
     * Command Response:<br>
     *         [Closure, Tax1,Tax2,Tax3,Tax4,Tax5,Tax6,Tax7,Tax8,StTax1,StTax2, StTax3,StTax4,StTax5,StTax6,StTax7,StTax8]<br>
     *             Closure - Number of fiscal record<br>
     *             Tax1,...,Tax8 - total sum of sells for current tax group (А,Б,В,... etc.)<br>
     *             StTax1,...,StTax8 - total sum of "сторно" for the current tax group (А,Б,В,... etc.)
     *
     */
    public abstract DeviceResponse FDDailyReport(EnumConstants.EnumDailyReportType type);

    /**
     * Makes report by Operators.
     *
     * @return DeviceResponse: Contains information about the operation (errors, response, request etc.)
     */
    public abstract DeviceResponse FDReportByOperators();

    /**
     * Creates report by PLU
     * @param pluType Type of Report:<br><br>
     *                X - makes X report <br>
     *                Z - makes Z report
     * @return DeviceResponse: Contains information about the operation (errors, response, request etc.)<br><br>
     *
     * Command Response:<br>
     *     P - successful
     *     F - unsuccessful
     */
    public abstract DeviceResponse FDReportByPLU(EnumConstants.EnumReportPLUType pluType);

    /**
     * Creates report by department
     * @param type Type of Report:<br><br>
     *                ZERO - X report by deparments
     *                ONE - prints info about the deperartments
     *                X - makes periodical X report by department<br>
     *                Z - makes periodical Z report by deparmtnet
     *
     * @return DeviceResponse: Contains information about the operation (errors, response, request etc.)<br><br>
     *
     * Command Response:<br>
     *     P - successful
     *     F - unsuccessful
     */
    public abstract DeviceResponse FDReportByDPT(EnumConstants.EnumReportDepartmentType type);

    /**
     * Makes report from date to date.
     *
     * @param startDate Date Format - DDMMYY
     * @param endDate Date Format - DDMMYY
     *
     * @return DeviceResponse: Contains information about the operation (errors, response, request etc.)
     */
    public abstract DeviceResponse FDReportByDates(String startDate, String endDate);

    /**
     * Opens fiscal receipt.
     *
     * @param operatorID ID of the operator.
     * @param operatorPass Operator password.
     * @param uniqueSaleNumber UNP of the sale. UNP Format: DY123456-0001-0000001<br>
     *         ID of fiscal device - two latin letters + 6 numbers(Example - DY123456)<br>
     *         ID of operator - four latin letters or numbers (Example - 0001)<br>
     *         Current sale number - seven numbers (Example 0000001)
     *
     * @return DeviceResponse: Contains information about the operation (errors, response, request etc.)<br><br>
     *
     * Command Response:<br>
     *     AllReceiptNumber, FiscReceiptNumber.
     */
    public abstract DeviceResponse FDStartFiscalReceipt(String operatorID, String operatorPass, String uniqueSaleNumber);

    /**
     * @return DeviceResponse: Contains information about the operation (errors, response, request etc.)<br><br>
     *
     * Command Response:<br>
     * llReceiptNumber, FiscReceiptNumber.
     */
    public abstract DeviceResponse FDEndFiscalReceipt();

    /**
     * Sale by PLU.
     *
     * @param pluID PLU ID.
     * @param quantity Quantity of the PLU.
     * @param price Price of PLU.
     * @param percent Percent discount/surcharge
     * @param netto Discount/surcharge sum.
     * @param toCorrectPrice Whether to correct or not the last sale in the recipt with the same single price, quantity and PLU ID. <br>
     *                       If true the percent and netto are ignored.
     *
     * @return DeviceResponse: Contains information about the operation (errors, response, request etc.)
     */
    public abstract DeviceResponse FDSaleByPLU(String pluID, String quantity, String price, String percent, String netto, boolean toCorrectPrice);

    /**
     * @param deptNumber Department ID.
     * @param price Sale price.
     * @param quantity Sale quantity.
     * @param percent Percent discount/surcharge.
     * @param netto Discount/surcharge sum.
     * @param toCorrectPrice Whether to correct or not the last sale in the recipt with the same single price, quantity and department ID. <br>
     *                       If true the percent and netto are ignored.
     *
     * @return DeviceResponse: Contains information about the operation (errors, response, request etc.)
     */
    public abstract DeviceResponse FDSaleByDPT(String deptNumber, String price, String quantity, String percent, String netto, boolean toCorrectPrice);

    /**
     * @param text1 Text describing the sale.
     * @param taxGroup Tax group.
     * @param price Sale price.
     * @param quantity Sale quantity.
     * @param percent Percent discount/surcharge.
     * @param netto Discount/surcharge sum.
     * @param toCorrectPrice Whether to correct or not the last sale in the recipt with the same single price and quantity. <br>
     *                       If true the percent and netto are ignored.
     *
     * @return DeviceResponse: Contains information about the operation (errors, response, request etc.)
     */
    public abstract DeviceResponse FDSaleItem(String text1, String taxGroup, String price, String quantity, String percent, String netto, boolean toCorrectPrice);

    /**
     * Total sum of Sale.
     * @param text1 First row for print - text;
     * @param text2 Second row for print - text;
     * @param paymentType Payment Types:<br>
     *                    CASH - In cash<br>
     * SALE_1 - Sale 1<br>
     * SALE_2 - Sale 2<br>
     * SALE_3D - Sale 3
     * SALE_3U - Sale 3
     * SALE_4B - Sale 4
     * SALE_4E - Sale 4
     *
     * @param amount The sale payment amount.
     *
     * @return DeviceResponse: Contains information about the operation (errors, response, request etc.)<br><br>
     *
     * Command Response:<br>
     * PaidCode Amount <br>
     *  PaidCode - One byte with the result <br>
     *      F - error <br>
     *      I - if sum for some of the tax groups is negative number.<br>
     *      D - if the paid sum is less then the total sum.<br>
     *      R - if the paid sum is bigger then the total sum.<br>
     *      E - negative sub total.<br><br>
     *
     *  Amount - Change. (depends on PaidCode)
     */
    public abstract DeviceResponse FDTotalSum(String text1, String text2, EnumConstants.EnumPaymentType paymentType, String amount);

    /**
     * Sub total of sale.
     * @param toPrintOnPaper Whether or not to print on paper.
     * @param showOnDisplay Whether or not to show on display.
     * @param percentDiscount Percent discount.
     *
     * @return DeviceResponse: Contains information about the operation (errors, response, request etc.)<br><br>
     *
     *     Command Response:<br>
     *         SubTotalTax1Tax2Tax3Tax4Tax5Tax6Tax7Tax8<br>
     *         SubTotal - Price till now.
     *         Tax1-10 - Price for tax group A,...,З.
     */
    public abstract DeviceResponse FDSubTotal(boolean toPrintOnPaper, boolean showOnDisplay, String percentDiscount);

    /**
     * Prints text while a fiscal receipt is open.
     * @param text Text to print
     *
     * @return DeviceResponse: Contains information about the operation (errors, response, request etc.)<br><br>
     */
    public abstract DeviceResponse FDPrintText(String text);

    /**
     * Prints buyers data.
     * @param clientID buyers ID.
     *
     * @return DeviceResponse: Contains information about the operation (errors, response, request etc.)<br><br>
     */
    public abstract DeviceResponse FDPrintBuyerData(String clientID);

    /**
     * Prints barcode.
     * @param barcodeType Type of the barcode
     * @param data Barcode data.
     * @param printPlace Where to print it - center, right, left.
     *
     * @return DeviceResponse: Contains information about the operation (errors, response, request etc.)<br><br>
     */
    public abstract DeviceResponse FDPrintBarcode(EnumConstants.EnumBarcodeType barcodeType, String data, EnumConstants.BarcodePrintPlace printPlace);

    /**
     * Get status for the receipt
     * @return  DeviceResponse: Contains information about the operation (errors, response, request etc.)<br><br>
     */
    public abstract DeviceResponse FDReceiptStatus();

    /**
     * Duplicates the receipt.
     * @return  DeviceResponse: Contains information about the operation (errors, response, request etc.)<br><br>
     */
    public abstract DeviceResponse FDPrintDuplicateReceipt();

    /**
     * Cancels the receipt.
     * @return  DeviceResponse: Contains information about the operation (errors, response, request etc.)<br><br>
     */
    public abstract DeviceResponse FDCancelReceipt();
}
