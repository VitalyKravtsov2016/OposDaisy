package com.daisy.devicecommunicationSDK;

import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.method.ScrollingMovementMethod;
import android.text.style.ForegroundColorSpan;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

public class TerminalFragment extends Fragment implements ServiceConnection, SerialListener {

    private static String TAG = "Simple BLE Terminal";

    private FiscalDevice device;
    private TextView sendText;
    private String deviceAddress;
    private String newline = "\r\n";
    private TextView receiveText;
    private SerialSocketBluetooth socket;
    private SerialService service;
    private boolean initialStart = true;
    private Connected connected = Connected.False;

    public TerminalFragment() {
    }

    /*
     * Lifecycle
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
        setRetainInstance(true);
        deviceAddress = getArguments().getString("device");
    }

    @Override
    public void onDestroy() {
        if (connected != Connected.False)
            disconnect();
        getActivity().stopService(new Intent(getActivity(), SerialService.class));
        super.onDestroy();
    }

    @Override
    public void onStart() {
        super.onStart();
        if (service != null)
            service.attach(this);
        else
            getActivity().startService(new Intent(getActivity(), SerialService.class)); // prevents service destroy on unbind from recreated activity caused by orientation change
    }

    @Override
    public void onStop() {
        if (service != null && !getActivity().isChangingConfigurations())
            service.detach();
        super.onStop();
    }

    @SuppressWarnings("deprecation")
    // onAttach(context) was added with API 23. onAttach(activity) works for all API versions
    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        getActivity().bindService(new Intent(getActivity(), SerialService.class), this, Context.BIND_AUTO_CREATE);
    }

    @Override
    public void onDetach() {
        try {
            getActivity().unbindService(this);
        } catch (Exception ignored) {
        }
        super.onDetach();
    }

    @Override
    public void onResume() {
        super.onResume();
        if (initialStart && service != null) {
            initialStart = false;
            getActivity().runOnUiThread(this::connect);
        }
    }

    @Override
    public void onServiceConnected(ComponentName name, IBinder binder) {
        service = ((SerialService.SerialBinder) binder).getService();
        if (initialStart && isResumed()) {
            initialStart = false;
            getActivity().runOnUiThread(this::connect);
        }
    }

    @Override
    public void onServiceDisconnected(ComponentName name) {
        service = null;
    }

    /*
     * UI
     */
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_terminal, container, false);
        receiveText = view.findViewById(R.id.receive_text);                          // TextView performance decreases with number of spans
        receiveText.setTextColor(getResources().getColor(R.color.colorRecieved)); // set as default color to reduce number of spans
        receiveText.setMovementMethod(ScrollingMovementMethod.getInstance());
        sendText = view.findViewById(R.id.send_text);

        View sendBtn = view.findViewById(R.id.send_btn);
        sendBtn.setOnClickListener(v -> {
            String text = sendText.getText().toString();
            switch (text) {
                case "1":
                    device.FDGetStatus();
                    break;
                case "2":
                    device.FDGetFinalRecord();
                    break;
                case "3":
                    device.FDGetDiagnosticInfo();
                    break;
                case "3.1":
                    device.FDGetTaxRates();
                    break;
                case "4":
                    device.FDProgramPLU("А", "10", "20", "cola", "3232323232", "1", "200");
                    break;
                case "5":
                    device.FDReadPLU("1");
                    break;
                case "6":
                    device.FDReadFirstPLU();
                    break;
                case "7":
                    device.FDReadNextPLU();
                    break;
                case "8":
                    device.FDDeletePLU("3");
                    break;
                case "9":
                    device.FDProgramDPT("1", "deptName", "A", "2");
                    break;
                case "10":
                    device.FDReadDPT("3");
                    break;
                case "11":
                    device.FDGetDateTime();
                    break;
                case "12":
                    device.FDSetDateTime("18-12-19", "12:48:20");
                    break;
                case "13":
                    device.FDGetConstants();
                    break;
                case "14":
                    device.FDGetFirmwareInfo();
                    break;
                case "15":
                    device.FDDailyReport(EnumConstants.EnumDailyReportType.Z_REPORT);
                    break;
                case "16":
                    device.FDReportByOperators();
                    break;
                case "17":
                    device.FDReportByPLU(EnumConstants.EnumReportPLUType.Z);
                    break;
                case "18":
                    device.FDReportByDPT(EnumConstants.EnumReportDepartmentType.Z);
                    break;
                case "19":
                    device.FDReportByDates("150819", "171219");
                    break;
                case "20":
                    device.FDStartFiscalReceipt("1", "1", "DY000600-OP01-0000001");
                    break;
                case "21":
                    device.FDEndFiscalReceipt();
                    break;
                case "22":
                    device.FDSaleByPLU("1", "1", "1,20","0", "0", false);
                    break;
                case "23":
                    device.FDSaleByDPT("1", "1.20", "1", "0", "0", false);
                    break;
                case "24":
                    device.FDSaleItem("Test text1", "А", "100", "1", "50", "0", false);
                    break;
                case "25":
                    device.FDSaleItem("Test text1", "А", "2.22", "1", "", "", true);
                    break;
                case "26":
                    device.FDSaleItem("Test text1", "А", "100", "1", "-50", "0", false);
                    break;
                case "27":
                    device.FDSaleItem("Test text1", "А", "100", "1", "0", "-80", false);
                    break;
                case "28":
                    device.FDTotalSum("text1", "text2", EnumConstants.EnumPaymentType.CASH, "5000");
                    break;
                case "29":
                    device.FDSubTotal(true, true, "0");
                    break;
                case "30":
                    device.FDSubTotal(true, true, "50");
                    break;
                case "31":
                    device.FDPrintText("print fiscal text");
                    break;
                case "32":
                    device.FDPrintBuyerData("1");
                    break;
                case "33":
                    device.FDPrintBarcode(EnumConstants.EnumBarcodeType.EAH8, "Print test", EnumConstants.BarcodePrintPlace.CENTER);
                    break;
                case "34":
                    device.FDReceiptStatus();
                    break;
                case "35":
                    device.FDPrintDuplicateReceipt();
                    break;
                case "36":
                    device.FDCancelReceipt();
                    break;
            }

        });

        View sendBtn3 = view.findViewById(R.id.send_btn3);
        sendBtn3.setOnClickListener(v -> device.FDMovePaper());

        View sendBtn2 = view.findViewById(R.id.send_btnExecuteCommand);
        sendBtn2.setOnClickListener(v -> device.FDMovePaper());

        return view;
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.menu_terminal, menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.clear) {
            receiveText.setText("");
            return true;
        } else if (id == R.id.newline) {
            String[] newlineNames = getResources().getStringArray(R.array.newline_names);
            String[] newlineValues = getResources().getStringArray(R.array.newline_values);
            int pos = java.util.Arrays.asList(newlineValues).indexOf(newline);
            AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
            builder.setTitle("Newline");
            builder.setSingleChoiceItems(newlineNames, pos, (dialog, item1) -> {
                newline = newlineValues[item1];
                dialog.dismiss();
            });
            builder.create().show();
            return true;
        } else {
            return super.onOptionsItemSelected(item);
        }
    }

    private void connect() {
        try {
            BluetoothAdapter bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
            BluetoothDevice device = bluetoothAdapter.getRemoteDevice(deviceAddress);
            String deviceName = device.getName() != null ? device.getName() : device.getAddress();
            status("connecting...");
            connected = Connected.Pending;
            socket = new SerialSocketBluetooth();
            service.connect(this, "Connected to " + deviceName);
            socket.connect(getContext(), service, device);
            this.device = new DeviceBulgaria(socket);
        } catch (Exception e) {
            onSerialConnectError(e);
        }
    }

    private void disconnect() {
        connected = Connected.False;
        service.disconnect();
        socket.disconnect();
        socket = null;
    }

    private void receive(byte[] data) {
        Log.i(TAG, "receive data length: " + data.length);
        Log.i(TAG, "receive data : " + EnumConstants.convertToHex(data));

        receiveText.append("DATA TO HEX: " + EnumConstants.convertToHex(data) + "\n");
        if(device.getStatus().equals(EnumErrorType.ERROR) ||
                device.getStatus().equals(EnumErrorType.ERROR_BYTE_3)){
            receiveText.append("ERROR:" + device.getError() + "\n\n\n");
        }else {
            receiveText.append("DATA RESPONSE: " + device.getResponse() + "\n\n\n");
        }
    }

    private void status(String str) {
        SpannableStringBuilder spn = new SpannableStringBuilder(str + '\n');
        spn.setSpan(new ForegroundColorSpan(getResources().getColor(R.color.colorStatus)), 0, spn.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        receiveText.append(spn);
    }

    /*
     * SerialListener
     */
    @Override
    public void onSerialConnect() {
        status("connected");
        connected = Connected.True;
    }

    @Override
    public void onSerialConnectError(Exception e) {
        status("connection failed: " + e.getMessage());
        disconnect();
    }

    @Override
    public void onSerialRead(byte[] data) {
        device.addResponse(data);
        receive(data);
    }

    @Override
    public void onSerialIoError(Exception e) {
        status("connection lost: " + e.getMessage());
        disconnect();
    }

    private enum Connected {False, Pending, True}
}
